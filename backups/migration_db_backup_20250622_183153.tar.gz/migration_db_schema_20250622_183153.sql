--
-- PostgreSQL database dump
--

-- Dumped from database version 16.8 (Debian 16.8-1.pgdg120+1)
-- Dumped by pg_dump version 16.8 (Debian 16.8-1.pgdg120+1)

-- Started on 2025-06-22 22:31:53 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 9 (class 2615 OID 16805)
-- Name: migration; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA migration;


ALTER SCHEMA migration OWNER TO postgres;

--
-- TOC entry 4304 (class 0 OID 0)
-- Dependencies: 9
-- Name: SCHEMA migration; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA migration IS 'Main application schema for migration data';


--
-- TOC entry 3 (class 3079 OID 16396)
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- TOC entry 4305 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- TOC entry 2 (class 3079 OID 16385)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- TOC entry 4306 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 4 (class 3079 OID 16477)
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- TOC entry 4307 (class 0 OID 0)
-- Dependencies: 4
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- TOC entry 1157 (class 1247 OID 20305)
-- Name: analysisstatus; Type: TYPE; Schema: migration; Owner: postgres
--

CREATE TYPE migration.analysisstatus AS ENUM (
    'PENDING',
    'IN_PROGRESS',
    'COMPLETED',
    'FAILED',
    'REQUIRES_INPUT'
);


ALTER TYPE migration.analysisstatus OWNER TO postgres;

--
-- TOC entry 1208 (class 1247 OID 20696)
-- Name: assessmentstatus; Type: TYPE; Schema: migration; Owner: postgres
--

CREATE TYPE migration.assessmentstatus AS ENUM (
    'PENDING',
    'IN_PROGRESS',
    'COMPLETED',
    'REVIEWED',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE migration.assessmentstatus OWNER TO postgres;

--
-- TOC entry 1205 (class 1247 OID 20680)
-- Name: assessmenttype; Type: TYPE; Schema: migration; Owner: postgres
--

CREATE TYPE migration.assessmenttype AS ENUM (
    'SIX_R_ANALYSIS',
    'RISK_ASSESSMENT',
    'COST_ANALYSIS',
    'TECHNICAL_ASSESSMENT',
    'BUSINESS_IMPACT',
    'SECURITY_ASSESSMENT',
    'COMPLIANCE_REVIEW'
);


ALTER TYPE migration.assessmenttype OWNER TO postgres;

--
-- TOC entry 1184 (class 1247 OID 20520)
-- Name: assetstatus; Type: TYPE; Schema: migration; Owner: postgres
--

CREATE TYPE migration.assetstatus AS ENUM (
    'DISCOVERED',
    'ASSESSED',
    'PLANNED',
    'MIGRATING',
    'MIGRATED',
    'FAILED',
    'EXCLUDED'
);


ALTER TYPE migration.assetstatus OWNER TO postgres;

--
-- TOC entry 1181 (class 1247 OID 20498)
-- Name: assettype; Type: TYPE; Schema: migration; Owner: postgres
--

CREATE TYPE migration.assettype AS ENUM (
    'SERVER',
    'DATABASE',
    'APPLICATION',
    'NETWORK',
    'LOAD_BALANCER',
    'STORAGE',
    'SECURITY_GROUP',
    'VIRTUAL_MACHINE',
    'CONTAINER',
    'OTHER'
);


ALTER TYPE migration.assettype OWNER TO postgres;

--
-- TOC entry 1073 (class 1247 OID 19718)
-- Name: migrationphase; Type: TYPE; Schema: migration; Owner: postgres
--

CREATE TYPE migration.migrationphase AS ENUM (
    'DISCOVERY',
    'ASSESS',
    'PLAN',
    'EXECUTE',
    'MODERNIZE',
    'FINOPS',
    'OBSERVABILITY',
    'DECOMMISSION'
);


ALTER TYPE migration.migrationphase OWNER TO postgres;

--
-- TOC entry 1070 (class 1247 OID 19706)
-- Name: migrationstatus; Type: TYPE; Schema: migration; Owner: postgres
--

CREATE TYPE migration.migrationstatus AS ENUM (
    'PLANNING',
    'IN_PROGRESS',
    'COMPLETED',
    'PAUSED',
    'CANCELLED'
);


ALTER TYPE migration.migrationstatus OWNER TO postgres;

--
-- TOC entry 1085 (class 1247 OID 19762)
-- Name: questiontype; Type: TYPE; Schema: migration; Owner: postgres
--

CREATE TYPE migration.questiontype AS ENUM (
    'TEXT',
    'SELECT',
    'MULTISELECT',
    'FILE_UPLOAD',
    'BOOLEAN',
    'NUMERIC'
);


ALTER TYPE migration.questiontype OWNER TO postgres;

--
-- TOC entry 1172 (class 1247 OID 20430)
-- Name: risklevel; Type: TYPE; Schema: migration; Owner: postgres
--

CREATE TYPE migration.risklevel AS ENUM (
    'LOW',
    'MEDIUM',
    'HIGH',
    'CRITICAL'
);


ALTER TYPE migration.risklevel OWNER TO postgres;

--
-- TOC entry 1160 (class 1247 OID 20316)
-- Name: sixrstrategy; Type: TYPE; Schema: migration; Owner: postgres
--

CREATE TYPE migration.sixrstrategy AS ENUM (
    'REHOST',
    'REPLATFORM',
    'REFACTOR',
    'REARCHITECT',
    'REPLACE',
    'REPURCHASE',
    'RETIRE',
    'RETAIN'
);


ALTER TYPE migration.sixrstrategy OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 253 (class 1259 OID 20465)
-- Name: access_audit_log; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.access_audit_log (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    action_type character varying(50) NOT NULL,
    resource_type character varying(50),
    resource_id character varying(255),
    client_account_id uuid,
    engagement_id uuid,
    session_id uuid,
    result character varying(20) NOT NULL,
    reason text,
    ip_address character varying(45),
    user_agent text,
    details json,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE migration.access_audit_log OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 19228)
-- Name: alembic_version; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE migration.alembic_version OWNER TO postgres;

--
-- TOC entry 260 (class 1259 OID 20709)
-- Name: assessments; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.assessments (
    id uuid NOT NULL,
    client_account_id uuid NOT NULL,
    engagement_id uuid NOT NULL,
    migration_id uuid NOT NULL,
    asset_id uuid,
    assessment_type migration.assessmenttype NOT NULL,
    status migration.assessmentstatus,
    title character varying(255) NOT NULL,
    description text,
    overall_score double precision,
    risk_level migration.risklevel,
    confidence_level double precision,
    recommended_strategy character varying(50),
    alternative_strategies json,
    strategy_rationale text,
    current_cost double precision,
    estimated_migration_cost double precision,
    estimated_target_cost double precision,
    cost_savings_potential double precision,
    roi_months integer,
    identified_risks json,
    risk_mitigation json,
    blockers json,
    dependencies_impact json,
    technical_complexity character varying(20),
    compatibility_score double precision,
    modernization_opportunities json,
    performance_impact json,
    business_criticality character varying(20),
    downtime_requirements json,
    user_impact text,
    compliance_considerations json,
    ai_insights json,
    ai_confidence double precision,
    ai_model_version character varying(50),
    estimated_effort_hours integer,
    estimated_duration_days integer,
    recommended_wave integer,
    prerequisites json,
    assessor character varying(100),
    assessment_date timestamp with time zone DEFAULT now(),
    review_date timestamp with time zone,
    approval_date timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE migration.assessments OWNER TO postgres;

--
-- TOC entry 261 (class 1259 OID 20741)
-- Name: asset_dependencies; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.asset_dependencies (
    id uuid NOT NULL,
    asset_id uuid NOT NULL,
    depends_on_asset_id uuid NOT NULL,
    dependency_type character varying(50) NOT NULL,
    description text,
    is_mock boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE migration.asset_dependencies OWNER TO postgres;

--
-- TOC entry 262 (class 1259 OID 20759)
-- Name: asset_embeddings; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.asset_embeddings (
    id uuid NOT NULL,
    asset_id uuid NOT NULL,
    client_account_id uuid NOT NULL,
    engagement_id uuid NOT NULL,
    embedding public.vector(1536),
    source_text text,
    embedding_model character varying(100),
    is_mock boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE migration.asset_embeddings OWNER TO postgres;

--
-- TOC entry 263 (class 1259 OID 20787)
-- Name: asset_tags; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.asset_tags (
    id uuid NOT NULL,
    asset_id uuid NOT NULL,
    tag_id uuid NOT NULL,
    confidence_score double precision,
    assigned_method character varying(50),
    assigned_by uuid,
    is_validated boolean,
    validated_by uuid,
    validated_at timestamp with time zone,
    is_mock boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE migration.asset_tags OWNER TO postgres;

--
-- TOC entry 254 (class 1259 OID 20535)
-- Name: assets; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.assets (
    id uuid NOT NULL,
    client_account_id uuid NOT NULL,
    engagement_id uuid NOT NULL,
    session_id uuid,
    migration_id uuid,
    name character varying(255) NOT NULL,
    asset_name character varying(255),
    hostname character varying(255),
    asset_type migration.assettype NOT NULL,
    description text,
    ip_address character varying(45),
    fqdn character varying(255),
    mac_address character varying(17),
    environment character varying(50),
    location character varying(100),
    datacenter character varying(100),
    rack_location character varying(50),
    availability_zone character varying(50),
    operating_system character varying(100),
    os_version character varying(50),
    cpu_cores integer,
    memory_gb double precision,
    storage_gb double precision,
    business_owner character varying(255),
    technical_owner character varying(255),
    department character varying(100),
    application_name character varying(255),
    technology_stack character varying(255),
    criticality character varying(20),
    business_criticality character varying(20),
    custom_attributes json,
    six_r_strategy migration.sixrstrategy,
    mapping_status character varying(20),
    migration_priority integer,
    migration_complexity character varying(20),
    migration_wave integer,
    sixr_ready character varying(50),
    status character varying(50),
    migration_status migration.assetstatus,
    dependencies json,
    related_assets json,
    discovery_method character varying(50),
    discovery_source character varying(100),
    discovery_timestamp timestamp with time zone,
    cpu_utilization_percent double precision,
    memory_utilization_percent double precision,
    disk_iops double precision,
    network_throughput_mbps double precision,
    completeness_score double precision,
    quality_score double precision,
    current_monthly_cost double precision,
    estimated_cloud_cost double precision,
    imported_by uuid,
    imported_at timestamp with time zone,
    source_filename character varying(255),
    raw_data json,
    field_mappings_used json,
    is_mock boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE migration.assets OWNER TO postgres;

--
-- TOC entry 233 (class 1259 OID 19887)
-- Name: client_access; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.client_access (
    id uuid NOT NULL,
    user_profile_id uuid NOT NULL,
    client_account_id uuid NOT NULL,
    access_level character varying(20) NOT NULL,
    permissions json,
    restricted_environments json,
    restricted_data_types json,
    granted_at timestamp with time zone DEFAULT now(),
    granted_by uuid NOT NULL,
    expires_at timestamp with time zone,
    is_active boolean,
    last_accessed_at timestamp with time zone,
    access_count integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE migration.client_access OWNER TO postgres;

--
-- TOC entry 228 (class 1259 OID 19815)
-- Name: client_accounts; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.client_accounts (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(100) NOT NULL,
    description text,
    industry character varying(100),
    company_size character varying(50),
    headquarters_location character varying(255),
    primary_contact_name character varying(255),
    primary_contact_email character varying(255),
    primary_contact_phone character varying(50),
    subscription_tier character varying(50),
    billing_contact_email character varying(255),
    settings json,
    branding json,
    business_objectives json,
    it_guidelines json,
    decision_criteria json,
    agent_preferences json,
    is_mock boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    created_by uuid,
    is_active boolean NOT NULL
);


ALTER TABLE migration.client_accounts OWNER TO postgres;

--
-- TOC entry 238 (class 1259 OID 20005)
-- Name: cmdb_sixr_analyses; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.cmdb_sixr_analyses (
    id uuid NOT NULL,
    client_account_id uuid NOT NULL,
    engagement_id uuid NOT NULL,
    analysis_name character varying(255) NOT NULL,
    description text,
    status character varying(50),
    total_assets integer,
    rehost_count integer,
    replatform_count integer,
    refactor_count integer,
    rearchitect_count integer,
    retire_count integer,
    retain_count integer,
    total_current_cost double precision,
    total_estimated_cost double precision,
    potential_savings double precision,
    analysis_results json,
    recommendations json,
    is_mock boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    created_by uuid
);


ALTER TABLE migration.cmdb_sixr_analyses OWNER TO postgres;

--
-- TOC entry 229 (class 1259 OID 19832)
-- Name: crewai_flow_state_extensions; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.crewai_flow_state_extensions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workflow_state_id uuid NOT NULL,
    session_id uuid NOT NULL,
    flow_id uuid NOT NULL,
    flow_persistence_data jsonb NOT NULL,
    agent_collaboration_log jsonb NOT NULL,
    memory_usage_metrics jsonb NOT NULL,
    knowledge_base_analytics jsonb NOT NULL,
    phase_execution_times jsonb NOT NULL,
    agent_performance_metrics jsonb NOT NULL,
    crew_coordination_analytics jsonb NOT NULL,
    learning_patterns jsonb NOT NULL,
    user_feedback_history jsonb NOT NULL,
    adaptation_metrics jsonb NOT NULL,
    resumption_checkpoints jsonb NOT NULL,
    state_snapshots jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE migration.crewai_flow_state_extensions OWNER TO postgres;

--
-- TOC entry 234 (class 1259 OID 19915)
-- Name: custom_target_fields; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.custom_target_fields (
    id uuid NOT NULL,
    client_account_id uuid NOT NULL,
    field_name character varying NOT NULL,
    field_type character varying NOT NULL,
    description text,
    is_required boolean,
    is_critical boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    created_by uuid,
    validation_schema json,
    default_value character varying,
    allowed_values json
);


ALTER TABLE migration.custom_target_fields OWNER TO postgres;

--
-- TOC entry 239 (class 1259 OID 20033)
-- Name: data_import_sessions; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.data_import_sessions (
    id uuid NOT NULL,
    client_account_id uuid NOT NULL,
    engagement_id uuid NOT NULL,
    session_name character varying(255) NOT NULL,
    session_display_name character varying(255),
    description text,
    is_default boolean NOT NULL,
    parent_session_id uuid,
    session_type character varying(50) NOT NULL,
    auto_created boolean NOT NULL,
    source_filename character varying(255),
    status character varying(20) NOT NULL,
    progress_percentage integer,
    total_imports integer,
    total_assets_processed integer,
    total_records_imported integer,
    data_quality_score integer,
    session_config json,
    business_context json,
    agent_insights json,
    started_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone,
    last_activity_at timestamp with time zone DEFAULT now(),
    created_by uuid NOT NULL,
    is_mock boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE migration.data_import_sessions OWNER TO postgres;

--
-- TOC entry 255 (class 1259 OID 20590)
-- Name: data_imports; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.data_imports (
    id uuid NOT NULL,
    client_account_id uuid,
    engagement_id uuid,
    session_id uuid,
    import_name character varying(255) NOT NULL,
    import_type character varying(50) NOT NULL,
    description text,
    source_filename character varying(255) NOT NULL,
    file_size_bytes integer,
    file_type character varying(100),
    file_hash character varying(64),
    status character varying(20) NOT NULL,
    progress_percentage double precision,
    total_records integer,
    processed_records integer,
    failed_records integer,
    import_config json,
    imported_by uuid NOT NULL,
    started_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone,
    is_mock boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE migration.data_imports OWNER TO postgres;

--
-- TOC entry 4308 (class 0 OID 0)
-- Dependencies: 255
-- Name: TABLE data_imports; Type: COMMENT; Schema: migration; Owner: postgres
--

COMMENT ON TABLE migration.data_imports IS 'Tracks data import jobs and their metadata, with multi-tenancy.';


--
-- TOC entry 268 (class 1259 OID 20892)
-- Name: data_quality_issues; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.data_quality_issues (
    id uuid NOT NULL,
    data_import_id uuid NOT NULL,
    raw_record_id uuid,
    issue_type character varying(50) NOT NULL,
    field_name character varying(255),
    current_value text,
    suggested_value text,
    severity character varying(20),
    confidence_score double precision,
    reasoning text,
    status character varying(20),
    resolution_method character varying(50),
    resolved_by uuid,
    resolution_notes text,
    detected_at timestamp with time zone DEFAULT now(),
    resolved_at timestamp with time zone
);


ALTER TABLE migration.data_quality_issues OWNER TO postgres;

--
-- TOC entry 4309 (class 0 OID 0)
-- Dependencies: 268
-- Name: TABLE data_quality_issues; Type: COMMENT; Schema: migration; Owner: postgres
--

COMMENT ON TABLE migration.data_quality_issues IS 'Tracks data quality issues identified during the import process.';


--
-- TOC entry 240 (class 1259 OID 20070)
-- Name: engagement_access; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.engagement_access (
    id uuid NOT NULL,
    user_profile_id uuid NOT NULL,
    engagement_id uuid NOT NULL,
    access_level character varying(20) NOT NULL,
    engagement_role character varying(100),
    permissions json,
    restricted_sessions json,
    allowed_session_types json,
    granted_at timestamp with time zone DEFAULT now(),
    granted_by uuid NOT NULL,
    expires_at timestamp with time zone,
    is_active boolean,
    last_accessed_at timestamp with time zone,
    access_count integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE migration.engagement_access OWNER TO postgres;

--
-- TOC entry 235 (class 1259 OID 19932)
-- Name: engagements; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.engagements (
    id uuid NOT NULL,
    client_account_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(100) NOT NULL,
    description text,
    engagement_type character varying(50),
    status character varying(50),
    priority character varying(20),
    start_date timestamp with time zone,
    target_completion_date timestamp with time zone,
    actual_completion_date timestamp with time zone,
    engagement_lead_id uuid,
    client_contact_name character varying(255),
    client_contact_email character varying(255),
    settings json,
    migration_scope json,
    team_preferences json,
    is_mock boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    created_by uuid,
    is_active boolean
);


ALTER TABLE migration.engagements OWNER TO postgres;

--
-- TOC entry 241 (class 1259 OID 20098)
-- Name: enhanced_access_audit_log; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.enhanced_access_audit_log (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    action_type character varying(50) NOT NULL,
    resource_type character varying(50),
    resource_id character varying(255),
    client_account_id uuid,
    engagement_id uuid,
    result character varying(20) NOT NULL,
    reason text,
    ip_address character varying(45),
    user_agent text,
    details json,
    user_role_level character varying(30),
    user_data_scope character varying(20),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE migration.enhanced_access_audit_log OWNER TO postgres;

--
-- TOC entry 242 (class 1259 OID 20124)
-- Name: enhanced_user_profiles; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.enhanced_user_profiles (
    user_id uuid NOT NULL,
    status character varying(20) NOT NULL,
    role_level character varying(30) NOT NULL,
    data_scope character varying(20) NOT NULL,
    scope_client_account_id uuid,
    scope_engagement_id uuid,
    registration_reason text,
    organization character varying(255),
    role_description character varying(255),
    phone_number character varying(20),
    manager_email character varying(255),
    approval_requested_at timestamp with time zone DEFAULT now(),
    approved_at timestamp with time zone,
    approved_by uuid,
    last_login_at timestamp with time zone,
    login_count integer,
    failed_login_attempts integer,
    is_deleted boolean,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    delete_reason text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE migration.enhanced_user_profiles OWNER TO postgres;

--
-- TOC entry 243 (class 1259 OID 20162)
-- Name: feedback; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.feedback (
    id uuid NOT NULL,
    feedback_type character varying(50) NOT NULL,
    page character varying(255),
    rating integer,
    comment text,
    category character varying(50),
    breadcrumb character varying(500),
    filename character varying(255),
    original_analysis json,
    user_corrections json,
    asset_type_override character varying(100),
    status character varying(20),
    processed boolean,
    user_agent character varying(500),
    user_timestamp character varying(50),
    client_ip character varying(45),
    client_account_id uuid,
    engagement_id uuid,
    learning_patterns_extracted json,
    confidence_impact double precision,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    processed_at timestamp with time zone
);


ALTER TABLE migration.feedback OWNER TO postgres;

--
-- TOC entry 244 (class 1259 OID 20183)
-- Name: feedback_summaries; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.feedback_summaries (
    id uuid NOT NULL,
    feedback_type character varying(50) NOT NULL,
    page character varying(255),
    time_period character varying(20),
    total_feedback integer,
    average_rating double precision,
    status_counts json,
    rating_distribution json,
    category_counts json,
    feedback_trend json,
    rating_trend json,
    client_account_id uuid,
    engagement_id uuid,
    last_calculated timestamp with time zone DEFAULT now(),
    calculation_duration_ms integer
);


ALTER TABLE migration.feedback_summaries OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 19678)
-- Name: flow_deletion_audit; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.flow_deletion_audit (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id uuid NOT NULL,
    flow_id uuid NOT NULL,
    client_account_id uuid NOT NULL,
    engagement_id uuid NOT NULL,
    user_id character varying NOT NULL,
    deletion_type character varying NOT NULL,
    deletion_reason text,
    deletion_method character varying NOT NULL,
    data_deleted jsonb NOT NULL,
    deletion_impact jsonb NOT NULL,
    cleanup_summary jsonb NOT NULL,
    shared_memory_cleaned boolean NOT NULL,
    knowledge_base_refs_cleaned jsonb NOT NULL,
    agent_memory_cleaned boolean NOT NULL,
    deleted_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_by character varying NOT NULL,
    deletion_duration_ms integer,
    recovery_possible boolean NOT NULL,
    recovery_data jsonb NOT NULL
);


ALTER TABLE migration.flow_deletion_audit OWNER TO postgres;

--
-- TOC entry 264 (class 1259 OID 20816)
-- Name: import_field_mappings; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.import_field_mappings (
    id uuid NOT NULL,
    data_import_id uuid NOT NULL,
    source_field character varying(255) NOT NULL,
    target_field character varying(255) NOT NULL,
    mapping_type character varying(50) NOT NULL,
    confidence_score double precision,
    is_user_defined boolean,
    is_validated boolean,
    validation_method character varying(50),
    status character varying(20),
    user_feedback text,
    original_ai_suggestion character varying(255),
    correction_reason text,
    transformation_logic json,
    validation_rules json,
    sample_values json,
    suggested_by character varying(50),
    validated_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    validated_at timestamp with time zone
);


ALTER TABLE migration.import_field_mappings OWNER TO postgres;

--
-- TOC entry 4310 (class 0 OID 0)
-- Dependencies: 264
-- Name: TABLE import_field_mappings; Type: COMMENT; Schema: migration; Owner: postgres
--

COMMENT ON TABLE migration.import_field_mappings IS 'Manages field mappings for data imports, including AI suggestions and user overrides.';


--
-- TOC entry 265 (class 1259 OID 20834)
-- Name: import_processing_steps; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.import_processing_steps (
    id uuid NOT NULL,
    data_import_id uuid NOT NULL,
    step_name character varying(100) NOT NULL,
    step_order integer NOT NULL,
    status character varying(20) NOT NULL,
    description text,
    input_data json,
    output_data json,
    error_details json,
    records_processed integer,
    duration_seconds double precision,
    started_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone
);


ALTER TABLE migration.import_processing_steps OWNER TO postgres;

--
-- TOC entry 4311 (class 0 OID 0)
-- Dependencies: 265
-- Name: TABLE import_processing_steps; Type: COMMENT; Schema: migration; Owner: postgres
--

COMMENT ON TABLE migration.import_processing_steps IS 'Tracks individual processing steps within a data import job for observability.';


--
-- TOC entry 221 (class 1259 OID 19692)
-- Name: llm_model_pricing; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.llm_model_pricing (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    provider character varying(100) NOT NULL,
    model_name character varying(255) NOT NULL,
    model_version character varying(100),
    input_cost_per_1k_tokens numeric(10,6) NOT NULL,
    output_cost_per_1k_tokens numeric(10,6) NOT NULL,
    currency character varying(10) NOT NULL,
    effective_from timestamp with time zone NOT NULL,
    effective_to timestamp with time zone,
    is_active boolean NOT NULL,
    source character varying(255),
    notes text
);


ALTER TABLE migration.llm_model_pricing OWNER TO postgres;

--
-- TOC entry 245 (class 1259 OID 20204)
-- Name: llm_usage_logs; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.llm_usage_logs (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    client_account_id uuid,
    engagement_id uuid,
    user_id integer,
    username character varying(255),
    session_id character varying(255),
    request_id character varying(255),
    endpoint character varying(500),
    page_context character varying(255),
    feature_context character varying(255),
    llm_provider character varying(100) NOT NULL,
    model_name character varying(255) NOT NULL,
    model_version character varying(100),
    input_tokens integer,
    output_tokens integer,
    total_tokens integer,
    input_cost numeric(10,6),
    output_cost numeric(10,6),
    total_cost numeric(10,6),
    cost_currency character varying(10) NOT NULL,
    response_time_ms integer,
    success boolean NOT NULL,
    error_type character varying(255),
    error_message text,
    request_data jsonb,
    response_data jsonb,
    additional_metadata jsonb,
    ip_address character varying(45),
    user_agent character varying(500)
);


ALTER TABLE migration.llm_usage_logs OWNER TO postgres;

--
-- TOC entry 246 (class 1259 OID 20233)
-- Name: llm_usage_summary; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.llm_usage_summary (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    period_type character varying(20) NOT NULL,
    period_start timestamp with time zone NOT NULL,
    period_end timestamp with time zone NOT NULL,
    client_account_id uuid,
    engagement_id uuid,
    user_id integer,
    llm_provider character varying(100),
    model_name character varying(255),
    page_context character varying(255),
    feature_context character varying(255),
    total_requests integer NOT NULL,
    successful_requests integer NOT NULL,
    failed_requests integer NOT NULL,
    total_input_tokens bigint NOT NULL,
    total_output_tokens bigint NOT NULL,
    total_tokens bigint NOT NULL,
    total_cost numeric(12,6) NOT NULL,
    avg_response_time_ms integer,
    min_response_time_ms integer,
    max_response_time_ms integer
);


ALTER TABLE migration.llm_usage_summary OWNER TO postgres;

--
-- TOC entry 247 (class 1259 OID 20257)
-- Name: mapping_learning_patterns; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.mapping_learning_patterns (
    id uuid NOT NULL,
    source_column character varying(255) NOT NULL,
    target_column character varying(255) NOT NULL,
    pattern_type character varying(50) NOT NULL,
    pattern_details json NOT NULL,
    confidence_score json,
    created_by character varying(100) NOT NULL,
    last_used_at timestamp with time zone DEFAULT now(),
    usage_count json,
    engagement_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE migration.mapping_learning_patterns OWNER TO postgres;

--
-- TOC entry 4312 (class 0 OID 0)
-- Dependencies: 247
-- Name: COLUMN mapping_learning_patterns.pattern_type; Type: COMMENT; Schema: migration; Owner: postgres
--

COMMENT ON COLUMN migration.mapping_learning_patterns.pattern_type IS 'e.g., ''regex'', ''value_map'', ''synonym''';


--
-- TOC entry 4313 (class 0 OID 0)
-- Dependencies: 247
-- Name: COLUMN mapping_learning_patterns.pattern_details; Type: COMMENT; Schema: migration; Owner: postgres
--

COMMENT ON COLUMN migration.mapping_learning_patterns.pattern_details IS 'Details of the learned pattern, e.g., the regex string or a value mapping dictionary';


--
-- TOC entry 4314 (class 0 OID 0)
-- Dependencies: 247
-- Name: COLUMN mapping_learning_patterns.created_by; Type: COMMENT; Schema: migration; Owner: postgres
--

COMMENT ON COLUMN migration.mapping_learning_patterns.created_by IS 'Identifier for the agent or user who created the pattern';


--
-- TOC entry 231 (class 1259 OID 19852)
-- Name: migration_logs; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.migration_logs (
    id integer NOT NULL,
    migration_id uuid NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now(),
    level character varying(20),
    message text NOT NULL,
    details json,
    phase migration.migrationphase,
    user_id character varying(100),
    action character varying(100)
);


ALTER TABLE migration.migration_logs OWNER TO postgres;

--
-- TOC entry 230 (class 1259 OID 19851)
-- Name: migration_logs_id_seq; Type: SEQUENCE; Schema: migration; Owner: postgres
--

CREATE SEQUENCE migration.migration_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE migration.migration_logs_id_seq OWNER TO postgres;

--
-- TOC entry 4315 (class 0 OID 0)
-- Dependencies: 230
-- Name: migration_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: migration; Owner: postgres
--

ALTER SEQUENCE migration.migration_logs_id_seq OWNED BY migration.migration_logs.id;


--
-- TOC entry 248 (class 1259 OID 20275)
-- Name: migration_waves; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.migration_waves (
    id uuid NOT NULL,
    client_account_id uuid NOT NULL,
    engagement_id uuid NOT NULL,
    wave_number integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    status character varying(50),
    planned_start_date timestamp with time zone,
    planned_end_date timestamp with time zone,
    actual_start_date timestamp with time zone,
    actual_end_date timestamp with time zone,
    total_assets integer,
    completed_assets integer,
    failed_assets integer,
    estimated_cost double precision,
    actual_cost double precision,
    estimated_effort_hours double precision,
    actual_effort_hours double precision,
    is_mock boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    created_by uuid
);


ALTER TABLE migration.migration_waves OWNER TO postgres;

--
-- TOC entry 222 (class 1259 OID 19735)
-- Name: migrations; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.migrations (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    status migration.migrationstatus,
    current_phase migration.migrationphase,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    start_date timestamp with time zone,
    target_completion_date timestamp with time zone,
    actual_completion_date timestamp with time zone,
    source_environment character varying(100),
    target_environment character varying(100),
    migration_strategy character varying(50),
    progress_percentage integer,
    total_assets integer,
    migrated_assets integer,
    ai_recommendations json,
    risk_assessment json,
    cost_estimates json,
    settings json
);


ALTER TABLE migration.migrations OWNER TO postgres;

--
-- TOC entry 266 (class 1259 OID 20847)
-- Name: raw_import_records; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.raw_import_records (
    id uuid NOT NULL,
    data_import_id uuid NOT NULL,
    client_account_id uuid,
    engagement_id uuid,
    session_id uuid,
    row_number integer NOT NULL,
    record_id character varying(255),
    raw_data json NOT NULL,
    processed_data json,
    validation_errors json,
    processing_notes text,
    is_processed boolean,
    is_valid boolean,
    asset_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    processed_at timestamp with time zone
);


ALTER TABLE migration.raw_import_records OWNER TO postgres;

--
-- TOC entry 4316 (class 0 OID 0)
-- Dependencies: 266
-- Name: TABLE raw_import_records; Type: COMMENT; Schema: migration; Owner: postgres
--

COMMENT ON TABLE migration.raw_import_records IS 'Stores individual raw data records from imported files before processing.';


--
-- TOC entry 223 (class 1259 OID 19745)
-- Name: role_permissions; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.role_permissions (
    id uuid NOT NULL,
    role_level character varying(30) NOT NULL,
    can_manage_platform_settings boolean,
    can_manage_all_clients boolean,
    can_manage_all_users boolean,
    can_purge_deleted_data boolean,
    can_view_system_logs boolean,
    can_create_clients boolean,
    can_modify_client_settings boolean,
    can_manage_client_users boolean,
    can_delete_client_data boolean,
    can_create_engagements boolean,
    can_modify_engagement_settings boolean,
    can_manage_engagement_users boolean,
    can_delete_engagement_data boolean,
    can_import_data boolean,
    can_export_data boolean,
    can_view_analytics boolean,
    can_modify_data boolean,
    can_configure_agents boolean,
    can_view_agent_insights boolean,
    can_approve_agent_decisions boolean,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE migration.role_permissions OWNER TO postgres;

--
-- TOC entry 249 (class 1259 OID 20333)
-- Name: sixr_analyses; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.sixr_analyses (
    id uuid NOT NULL,
    migration_id uuid,
    client_account_id uuid NOT NULL,
    engagement_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    status migration.analysisstatus NOT NULL,
    priority integer,
    application_ids json,
    application_data json,
    current_iteration integer,
    progress_percentage double precision,
    estimated_completion timestamp with time zone,
    final_recommendation migration.sixrstrategy,
    confidence_score double precision,
    created_by character varying(100),
    updated_by character varying(100),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    analysis_config json
);


ALTER TABLE migration.sixr_analyses OWNER TO postgres;

--
-- TOC entry 256 (class 1259 OID 20619)
-- Name: sixr_analysis_parameters; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.sixr_analysis_parameters (
    id uuid NOT NULL,
    analysis_id uuid NOT NULL,
    iteration_number integer NOT NULL,
    business_value double precision NOT NULL,
    technical_complexity double precision NOT NULL,
    migration_urgency double precision NOT NULL,
    compliance_requirements double precision NOT NULL,
    cost_sensitivity double precision NOT NULL,
    risk_tolerance double precision NOT NULL,
    innovation_priority double precision NOT NULL,
    application_type character varying(20),
    parameter_source character varying(50),
    confidence_level double precision,
    created_by character varying(100),
    updated_by character varying(100),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    parameter_notes text,
    validation_status character varying(20)
);


ALTER TABLE migration.sixr_analysis_parameters OWNER TO postgres;

--
-- TOC entry 257 (class 1259 OID 20633)
-- Name: sixr_iterations; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.sixr_iterations (
    id uuid NOT NULL,
    analysis_id uuid NOT NULL,
    iteration_number integer NOT NULL,
    iteration_name character varying(255),
    iteration_reason text,
    stakeholder_feedback text,
    parameter_changes json,
    question_responses json,
    recommendation_data json,
    confidence_score double precision,
    analysis_duration double precision,
    agent_insights json,
    status character varying(20),
    error_details json,
    created_by character varying(100),
    created_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone
);


ALTER TABLE migration.sixr_iterations OWNER TO postgres;

--
-- TOC entry 224 (class 1259 OID 19752)
-- Name: sixr_parameters; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.sixr_parameters (
    id uuid NOT NULL,
    parameter_key character varying(255) NOT NULL,
    value json NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE migration.sixr_parameters OWNER TO postgres;

--
-- TOC entry 258 (class 1259 OID 20647)
-- Name: sixr_question_responses; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.sixr_question_responses (
    id uuid NOT NULL,
    analysis_id uuid NOT NULL,
    iteration_number integer NOT NULL,
    question_id character varying(100) NOT NULL,
    response_value json,
    response_text text,
    confidence double precision,
    source character varying(50),
    response_time double precision,
    validation_status character varying(20),
    validation_errors json,
    created_by character varying(100),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE migration.sixr_question_responses OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 19775)
-- Name: sixr_questions; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.sixr_questions (
    id uuid NOT NULL,
    question_id character varying(100) NOT NULL,
    question_text text NOT NULL,
    question_type migration.questiontype NOT NULL,
    category character varying(100) NOT NULL,
    priority integer,
    required boolean,
    active boolean,
    options json,
    validation_rules json,
    help_text text,
    depends_on character varying(100),
    show_conditions json,
    skip_conditions json,
    created_by character varying(100),
    updated_by character varying(100),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    version character varying(20),
    parent_question_id character varying(100)
);


ALTER TABLE migration.sixr_questions OWNER TO postgres;

--
-- TOC entry 259 (class 1259 OID 20666)
-- Name: sixr_recommendations; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.sixr_recommendations (
    id uuid NOT NULL,
    analysis_id uuid NOT NULL,
    iteration_number integer,
    recommended_strategy migration.sixrstrategy NOT NULL,
    confidence_score double precision NOT NULL,
    strategy_scores json,
    key_factors json,
    assumptions json,
    next_steps json,
    estimated_effort character varying(50),
    estimated_timeline character varying(100),
    estimated_cost_impact character varying(50),
    risk_factors json,
    business_benefits json,
    technical_benefits json,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    created_by character varying(100)
);


ALTER TABLE migration.sixr_recommendations OWNER TO postgres;

--
-- TOC entry 250 (class 1259 OID 20360)
-- Name: soft_deleted_items; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.soft_deleted_items (
    id uuid NOT NULL,
    item_type character varying(30) NOT NULL,
    item_id uuid NOT NULL,
    item_name character varying(255),
    client_account_id uuid,
    engagement_id uuid,
    deleted_by uuid NOT NULL,
    deleted_at timestamp with time zone DEFAULT now(),
    delete_reason text,
    reviewed_by uuid,
    reviewed_at timestamp with time zone,
    review_decision character varying(20),
    review_notes text,
    purged_at timestamp with time zone,
    purged_by uuid,
    status character varying(20),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE migration.soft_deleted_items OWNER TO postgres;

--
-- TOC entry 236 (class 1259 OID 19960)
-- Name: tags; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.tags (
    id uuid NOT NULL,
    client_account_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    category character varying(50) NOT NULL,
    description text,
    reference_embedding public.vector(1536),
    confidence_threshold double precision,
    is_active boolean,
    is_mock boolean NOT NULL,
    usage_count integer,
    last_used timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE migration.tags OWNER TO postgres;

--
-- TOC entry 269 (class 1259 OID 20916)
-- Name: test_table; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.test_table (
    id integer
);


ALTER TABLE migration.test_table OWNER TO postgres;

--
-- TOC entry 237 (class 1259 OID 19979)
-- Name: user_account_associations; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.user_account_associations (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    client_account_id uuid NOT NULL,
    role character varying(50) NOT NULL,
    is_mock boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    created_by uuid
);


ALTER TABLE migration.user_account_associations OWNER TO postgres;

--
-- TOC entry 232 (class 1259 OID 19867)
-- Name: user_profiles; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.user_profiles (
    user_id uuid NOT NULL,
    status character varying(20) NOT NULL,
    approval_requested_at timestamp with time zone DEFAULT now(),
    approved_at timestamp with time zone,
    approved_by uuid,
    registration_reason text,
    organization character varying(255),
    role_description character varying(255),
    requested_access_level character varying(20),
    phone_number character varying(20),
    manager_email character varying(255),
    linkedin_profile character varying(255),
    last_login_at timestamp with time zone,
    login_count integer,
    failed_login_attempts integer,
    last_failed_login timestamp with time zone,
    notification_preferences json,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE migration.user_profiles OWNER TO postgres;

--
-- TOC entry 251 (class 1259 OID 20397)
-- Name: user_roles; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.user_roles (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    role_type character varying(50) NOT NULL,
    role_name character varying(100) NOT NULL,
    description text,
    permissions json,
    scope_type character varying(20),
    scope_client_id uuid,
    scope_engagement_id uuid,
    is_active boolean,
    assigned_at timestamp with time zone DEFAULT now(),
    assigned_by uuid NOT NULL,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE migration.user_roles OWNER TO postgres;

--
-- TOC entry 226 (class 1259 OID 19785)
-- Name: users; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.users (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255),
    first_name character varying(100),
    last_name character varying(100),
    is_active boolean,
    is_verified boolean,
    is_mock boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    last_login timestamp with time zone
);


ALTER TABLE migration.users OWNER TO postgres;

--
-- TOC entry 252 (class 1259 OID 20439)
-- Name: wave_plans; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.wave_plans (
    id uuid NOT NULL,
    client_account_id uuid NOT NULL,
    engagement_id uuid NOT NULL,
    migration_id uuid NOT NULL,
    wave_number integer NOT NULL,
    wave_name character varying(255),
    description text,
    planned_start_date timestamp with time zone,
    planned_end_date timestamp with time zone,
    actual_start_date timestamp with time zone,
    actual_end_date timestamp with time zone,
    total_assets integer,
    completed_assets integer,
    estimated_effort_hours integer,
    estimated_cost double precision,
    prerequisites json,
    dependencies json,
    constraints json,
    overall_risk_level migration.risklevel,
    complexity_score double precision,
    success_criteria json,
    status character varying(50),
    progress_percentage double precision,
    ai_recommendations json,
    optimization_score double precision,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE migration.wave_plans OWNER TO postgres;

--
-- TOC entry 267 (class 1259 OID 20880)
-- Name: workflow_progress; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.workflow_progress (
    id uuid NOT NULL,
    asset_id uuid NOT NULL,
    stage character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    notes text,
    is_mock boolean NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone
);


ALTER TABLE migration.workflow_progress OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 19797)
-- Name: workflow_states; Type: TABLE; Schema: migration; Owner: postgres
--

CREATE TABLE migration.workflow_states (
    id uuid NOT NULL,
    flow_id uuid NOT NULL,
    session_id uuid NOT NULL,
    client_account_id uuid NOT NULL,
    engagement_id uuid NOT NULL,
    user_id character varying NOT NULL,
    workflow_type character varying NOT NULL,
    current_phase character varying NOT NULL,
    status character varying NOT NULL,
    progress_percentage double precision NOT NULL,
    phase_completion json NOT NULL,
    crew_status json NOT NULL,
    state_data json NOT NULL,
    field_mappings json,
    cleaned_data json,
    asset_inventory json,
    dependencies json,
    technical_debt json,
    data_quality_metrics json,
    agent_insights json,
    success_criteria json,
    errors json NOT NULL,
    warnings json NOT NULL,
    workflow_log json NOT NULL,
    discovery_summary json,
    assessment_flow_package json,
    database_assets_created json NOT NULL,
    database_integration_status character varying NOT NULL,
    learning_scope character varying NOT NULL,
    memory_isolation_level character varying NOT NULL,
    shared_memory_id character varying,
    expiration_date timestamp with time zone,
    auto_cleanup_eligible boolean NOT NULL,
    deletion_scheduled_at timestamp with time zone,
    last_user_activity timestamp with time zone DEFAULT now() NOT NULL,
    flow_resumption_data jsonb NOT NULL,
    agent_memory_refs jsonb NOT NULL,
    knowledge_base_refs jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone
);


ALTER TABLE migration.workflow_states OWNER TO postgres;

--
-- TOC entry 3747 (class 2604 OID 19855)
-- Name: migration_logs id; Type: DEFAULT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.migration_logs ALTER COLUMN id SET DEFAULT nextval('migration.migration_logs_id_seq'::regclass);


--
-- TOC entry 3884 (class 2606 OID 19986)
-- Name: user_account_associations _user_client_account_uc; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.user_account_associations
    ADD CONSTRAINT _user_client_account_uc UNIQUE (user_id, client_account_id);


--
-- TOC entry 3987 (class 2606 OID 20472)
-- Name: access_audit_log access_audit_log_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.access_audit_log
    ADD CONSTRAINT access_audit_log_pkey PRIMARY KEY (id);


--
-- TOC entry 3798 (class 2606 OID 19232)
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- TOC entry 4021 (class 2606 OID 20717)
-- Name: assessments assessments_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.assessments
    ADD CONSTRAINT assessments_pkey PRIMARY KEY (id);


--
-- TOC entry 4026 (class 2606 OID 20748)
-- Name: asset_dependencies asset_dependencies_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.asset_dependencies
    ADD CONSTRAINT asset_dependencies_pkey PRIMARY KEY (id);


--
-- TOC entry 4028 (class 2606 OID 20766)
-- Name: asset_embeddings asset_embeddings_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.asset_embeddings
    ADD CONSTRAINT asset_embeddings_pkey PRIMARY KEY (id);


--
-- TOC entry 4035 (class 2606 OID 20792)
-- Name: asset_tags asset_tags_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.asset_tags
    ADD CONSTRAINT asset_tags_pkey PRIMARY KEY (id);


--
-- TOC entry 3993 (class 2606 OID 20542)
-- Name: assets assets_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.assets
    ADD CONSTRAINT assets_pkey PRIMARY KEY (id);


--
-- TOC entry 3861 (class 2606 OID 19895)
-- Name: client_access client_access_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.client_access
    ADD CONSTRAINT client_access_pkey PRIMARY KEY (id);


--
-- TOC entry 3843 (class 2606 OID 19822)
-- Name: client_accounts client_accounts_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.client_accounts
    ADD CONSTRAINT client_accounts_pkey PRIMARY KEY (id);


--
-- TOC entry 3891 (class 2606 OID 20012)
-- Name: cmdb_sixr_analyses cmdb_sixr_analyses_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.cmdb_sixr_analyses
    ADD CONSTRAINT cmdb_sixr_analyses_pkey PRIMARY KEY (id);


--
-- TOC entry 3849 (class 2606 OID 19841)
-- Name: crewai_flow_state_extensions crewai_flow_state_extensions_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.crewai_flow_state_extensions
    ADD CONSTRAINT crewai_flow_state_extensions_pkey PRIMARY KEY (id);


--
-- TOC entry 3867 (class 2606 OID 19921)
-- Name: custom_target_fields custom_target_fields_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.custom_target_fields
    ADD CONSTRAINT custom_target_fields_pkey PRIMARY KEY (id);


--
-- TOC entry 3898 (class 2606 OID 20042)
-- Name: data_import_sessions data_import_sessions_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.data_import_sessions
    ADD CONSTRAINT data_import_sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 4007 (class 2606 OID 20598)
-- Name: data_imports data_imports_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.data_imports
    ADD CONSTRAINT data_imports_pkey PRIMARY KEY (id);


--
-- TOC entry 4048 (class 2606 OID 20899)
-- Name: data_quality_issues data_quality_issues_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.data_quality_issues
    ADD CONSTRAINT data_quality_issues_pkey PRIMARY KEY (id);


--
-- TOC entry 3907 (class 2606 OID 20078)
-- Name: engagement_access engagement_access_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.engagement_access
    ADD CONSTRAINT engagement_access_pkey PRIMARY KEY (id);


--
-- TOC entry 3869 (class 2606 OID 19939)
-- Name: engagements engagements_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.engagements
    ADD CONSTRAINT engagements_pkey PRIMARY KEY (id);


--
-- TOC entry 3913 (class 2606 OID 20105)
-- Name: enhanced_access_audit_log enhanced_access_audit_log_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.enhanced_access_audit_log
    ADD CONSTRAINT enhanced_access_audit_log_pkey PRIMARY KEY (id);


--
-- TOC entry 3918 (class 2606 OID 20132)
-- Name: enhanced_user_profiles enhanced_user_profiles_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.enhanced_user_profiles
    ADD CONSTRAINT enhanced_user_profiles_pkey PRIMARY KEY (user_id);


--
-- TOC entry 3924 (class 2606 OID 20169)
-- Name: feedback feedback_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.feedback
    ADD CONSTRAINT feedback_pkey PRIMARY KEY (id);


--
-- TOC entry 3929 (class 2606 OID 20190)
-- Name: feedback_summaries feedback_summaries_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.feedback_summaries
    ADD CONSTRAINT feedback_summaries_pkey PRIMARY KEY (id);


--
-- TOC entry 3800 (class 2606 OID 19686)
-- Name: flow_deletion_audit flow_deletion_audit_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.flow_deletion_audit
    ADD CONSTRAINT flow_deletion_audit_pkey PRIMARY KEY (id);


--
-- TOC entry 4040 (class 2606 OID 20823)
-- Name: import_field_mappings import_field_mappings_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.import_field_mappings
    ADD CONSTRAINT import_field_mappings_pkey PRIMARY KEY (id);


--
-- TOC entry 4042 (class 2606 OID 20841)
-- Name: import_processing_steps import_processing_steps_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.import_processing_steps
    ADD CONSTRAINT import_processing_steps_pkey PRIMARY KEY (id);


--
-- TOC entry 3809 (class 2606 OID 19700)
-- Name: llm_model_pricing llm_model_pricing_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.llm_model_pricing
    ADD CONSTRAINT llm_model_pricing_pkey PRIMARY KEY (id);


--
-- TOC entry 3944 (class 2606 OID 20212)
-- Name: llm_usage_logs llm_usage_logs_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.llm_usage_logs
    ADD CONSTRAINT llm_usage_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 3949 (class 2606 OID 20241)
-- Name: llm_usage_summary llm_usage_summary_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.llm_usage_summary
    ADD CONSTRAINT llm_usage_summary_pkey PRIMARY KEY (id);


--
-- TOC entry 3956 (class 2606 OID 20266)
-- Name: mapping_learning_patterns mapping_learning_patterns_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.mapping_learning_patterns
    ADD CONSTRAINT mapping_learning_patterns_pkey PRIMARY KEY (id);


--
-- TOC entry 3856 (class 2606 OID 19860)
-- Name: migration_logs migration_logs_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.migration_logs
    ADD CONSTRAINT migration_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 3964 (class 2606 OID 20282)
-- Name: migration_waves migration_waves_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.migration_waves
    ADD CONSTRAINT migration_waves_pkey PRIMARY KEY (id);


--
-- TOC entry 3815 (class 2606 OID 19742)
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 4044 (class 2606 OID 20854)
-- Name: raw_import_records raw_import_records_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.raw_import_records
    ADD CONSTRAINT raw_import_records_pkey PRIMARY KEY (id);


--
-- TOC entry 3818 (class 2606 OID 19750)
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 3970 (class 2606 OID 20340)
-- Name: sixr_analyses sixr_analyses_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.sixr_analyses
    ADD CONSTRAINT sixr_analyses_pkey PRIMARY KEY (id);


--
-- TOC entry 4010 (class 2606 OID 20626)
-- Name: sixr_analysis_parameters sixr_analysis_parameters_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.sixr_analysis_parameters
    ADD CONSTRAINT sixr_analysis_parameters_pkey PRIMARY KEY (id);


--
-- TOC entry 4013 (class 2606 OID 20640)
-- Name: sixr_iterations sixr_iterations_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.sixr_iterations
    ADD CONSTRAINT sixr_iterations_pkey PRIMARY KEY (id);


--
-- TOC entry 3821 (class 2606 OID 19759)
-- Name: sixr_parameters sixr_parameters_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.sixr_parameters
    ADD CONSTRAINT sixr_parameters_pkey PRIMARY KEY (id);


--
-- TOC entry 4016 (class 2606 OID 20654)
-- Name: sixr_question_responses sixr_question_responses_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.sixr_question_responses
    ADD CONSTRAINT sixr_question_responses_pkey PRIMARY KEY (id);


--
-- TOC entry 3825 (class 2606 OID 19782)
-- Name: sixr_questions sixr_questions_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.sixr_questions
    ADD CONSTRAINT sixr_questions_pkey PRIMARY KEY (id);


--
-- TOC entry 4019 (class 2606 OID 20672)
-- Name: sixr_recommendations sixr_recommendations_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.sixr_recommendations
    ADD CONSTRAINT sixr_recommendations_pkey PRIMARY KEY (id);


--
-- TOC entry 3975 (class 2606 OID 20368)
-- Name: soft_deleted_items soft_deleted_items_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.soft_deleted_items
    ADD CONSTRAINT soft_deleted_items_pkey PRIMARY KEY (id);


--
-- TOC entry 3882 (class 2606 OID 19967)
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- TOC entry 3811 (class 2606 OID 19702)
-- Name: llm_model_pricing uq_model_pricing_version_date; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.llm_model_pricing
    ADD CONSTRAINT uq_model_pricing_version_date UNIQUE (provider, model_name, model_version, effective_from);


--
-- TOC entry 3951 (class 2606 OID 20243)
-- Name: llm_usage_summary uq_usage_summary_period_context; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.llm_usage_summary
    ADD CONSTRAINT uq_usage_summary_period_context UNIQUE (period_type, period_start, client_account_id, engagement_id, user_id, llm_provider, model_name, page_context, feature_context);


--
-- TOC entry 3889 (class 2606 OID 19984)
-- Name: user_account_associations user_account_associations_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.user_account_associations
    ADD CONSTRAINT user_account_associations_pkey PRIMARY KEY (id);


--
-- TOC entry 3859 (class 2606 OID 19875)
-- Name: user_profiles user_profiles_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (user_id);


--
-- TOC entry 3980 (class 2606 OID 20405)
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- TOC entry 3831 (class 2606 OID 19792)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3985 (class 2606 OID 20446)
-- Name: wave_plans wave_plans_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.wave_plans
    ADD CONSTRAINT wave_plans_pkey PRIMARY KEY (id);


--
-- TOC entry 4046 (class 2606 OID 20886)
-- Name: workflow_progress workflow_progress_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.workflow_progress
    ADD CONSTRAINT workflow_progress_pkey PRIMARY KEY (id);


--
-- TOC entry 3841 (class 2606 OID 19806)
-- Name: workflow_states workflow_states_pkey; Type: CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.workflow_states
    ADD CONSTRAINT workflow_states_pkey PRIMARY KEY (id);


--
-- TOC entry 3933 (class 1259 OID 20223)
-- Name: idx_llm_usage_client_account; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX idx_llm_usage_client_account ON migration.llm_usage_logs USING btree (client_account_id);


--
-- TOC entry 3934 (class 1259 OID 20224)
-- Name: idx_llm_usage_cost_analysis; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX idx_llm_usage_cost_analysis ON migration.llm_usage_logs USING btree (client_account_id, llm_provider, model_name, created_at);


--
-- TOC entry 3935 (class 1259 OID 20225)
-- Name: idx_llm_usage_created_at; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX idx_llm_usage_created_at ON migration.llm_usage_logs USING btree (created_at);


--
-- TOC entry 3936 (class 1259 OID 20226)
-- Name: idx_llm_usage_engagement; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX idx_llm_usage_engagement ON migration.llm_usage_logs USING btree (engagement_id);


--
-- TOC entry 3937 (class 1259 OID 20227)
-- Name: idx_llm_usage_feature_context; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX idx_llm_usage_feature_context ON migration.llm_usage_logs USING btree (feature_context);


--
-- TOC entry 3938 (class 1259 OID 20228)
-- Name: idx_llm_usage_page_context; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX idx_llm_usage_page_context ON migration.llm_usage_logs USING btree (page_context);


--
-- TOC entry 3939 (class 1259 OID 20229)
-- Name: idx_llm_usage_provider_model; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX idx_llm_usage_provider_model ON migration.llm_usage_logs USING btree (llm_provider, model_name);


--
-- TOC entry 3940 (class 1259 OID 20230)
-- Name: idx_llm_usage_reporting; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX idx_llm_usage_reporting ON migration.llm_usage_logs USING btree (client_account_id, created_at, success);


--
-- TOC entry 3941 (class 1259 OID 20231)
-- Name: idx_llm_usage_success; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX idx_llm_usage_success ON migration.llm_usage_logs USING btree (success);


--
-- TOC entry 3942 (class 1259 OID 20232)
-- Name: idx_llm_usage_user; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX idx_llm_usage_user ON migration.llm_usage_logs USING btree (user_id);


--
-- TOC entry 3806 (class 1259 OID 19703)
-- Name: idx_model_pricing_active; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX idx_model_pricing_active ON migration.llm_model_pricing USING btree (is_active, effective_from, effective_to);


--
-- TOC entry 3807 (class 1259 OID 19704)
-- Name: idx_model_pricing_provider_model; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX idx_model_pricing_provider_model ON migration.llm_model_pricing USING btree (provider, model_name);


--
-- TOC entry 3945 (class 1259 OID 20254)
-- Name: idx_usage_summary_client; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX idx_usage_summary_client ON migration.llm_usage_summary USING btree (client_account_id, period_start);


--
-- TOC entry 3946 (class 1259 OID 20255)
-- Name: idx_usage_summary_model; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX idx_usage_summary_model ON migration.llm_usage_summary USING btree (llm_provider, model_name, period_start);


--
-- TOC entry 3947 (class 1259 OID 20256)
-- Name: idx_usage_summary_period; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX idx_usage_summary_period ON migration.llm_usage_summary USING btree (period_type, period_start, period_end);


--
-- TOC entry 3988 (class 1259 OID 20493)
-- Name: ix_access_audit_log_action_type; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_access_audit_log_action_type ON migration.access_audit_log USING btree (action_type);


--
-- TOC entry 3989 (class 1259 OID 20494)
-- Name: ix_access_audit_log_created_at; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_access_audit_log_created_at ON migration.access_audit_log USING btree (created_at);


--
-- TOC entry 3990 (class 1259 OID 20495)
-- Name: ix_access_audit_log_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_access_audit_log_id ON migration.access_audit_log USING btree (id);


--
-- TOC entry 3991 (class 1259 OID 20496)
-- Name: ix_access_audit_log_user_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_access_audit_log_user_id ON migration.access_audit_log USING btree (user_id);


--
-- TOC entry 4022 (class 1259 OID 20738)
-- Name: ix_assessments_client_account_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_assessments_client_account_id ON migration.assessments USING btree (client_account_id);


--
-- TOC entry 4023 (class 1259 OID 20739)
-- Name: ix_assessments_engagement_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_assessments_engagement_id ON migration.assessments USING btree (engagement_id);


--
-- TOC entry 4024 (class 1259 OID 20740)
-- Name: ix_assessments_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_assessments_id ON migration.assessments USING btree (id);


--
-- TOC entry 4029 (class 1259 OID 20782)
-- Name: ix_asset_embeddings_asset_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_asset_embeddings_asset_id ON migration.asset_embeddings USING btree (asset_id);


--
-- TOC entry 4030 (class 1259 OID 20783)
-- Name: ix_asset_embeddings_client_account_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_asset_embeddings_client_account_id ON migration.asset_embeddings USING btree (client_account_id);


--
-- TOC entry 4031 (class 1259 OID 20784)
-- Name: ix_asset_embeddings_engagement_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_asset_embeddings_engagement_id ON migration.asset_embeddings USING btree (engagement_id);


--
-- TOC entry 4032 (class 1259 OID 20785)
-- Name: ix_asset_embeddings_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_asset_embeddings_id ON migration.asset_embeddings USING btree (id);


--
-- TOC entry 4033 (class 1259 OID 20786)
-- Name: ix_asset_embeddings_is_mock; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_asset_embeddings_is_mock ON migration.asset_embeddings USING btree (is_mock);


--
-- TOC entry 4036 (class 1259 OID 20813)
-- Name: ix_asset_tags_asset_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_asset_tags_asset_id ON migration.asset_tags USING btree (asset_id);


--
-- TOC entry 4037 (class 1259 OID 20814)
-- Name: ix_asset_tags_is_mock; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_asset_tags_is_mock ON migration.asset_tags USING btree (is_mock);


--
-- TOC entry 4038 (class 1259 OID 20815)
-- Name: ix_asset_tags_tag_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_asset_tags_tag_id ON migration.asset_tags USING btree (tag_id);


--
-- TOC entry 3994 (class 1259 OID 20578)
-- Name: ix_assets_asset_type; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_assets_asset_type ON migration.assets USING btree (asset_type);


--
-- TOC entry 3995 (class 1259 OID 20579)
-- Name: ix_assets_client_account_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_assets_client_account_id ON migration.assets USING btree (client_account_id);


--
-- TOC entry 3996 (class 1259 OID 20580)
-- Name: ix_assets_engagement_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_assets_engagement_id ON migration.assets USING btree (engagement_id);


--
-- TOC entry 3997 (class 1259 OID 20581)
-- Name: ix_assets_environment; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_assets_environment ON migration.assets USING btree (environment);


--
-- TOC entry 3998 (class 1259 OID 20582)
-- Name: ix_assets_hostname; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_assets_hostname ON migration.assets USING btree (hostname);


--
-- TOC entry 3999 (class 1259 OID 20583)
-- Name: ix_assets_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_assets_id ON migration.assets USING btree (id);


--
-- TOC entry 4000 (class 1259 OID 20584)
-- Name: ix_assets_is_mock; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_assets_is_mock ON migration.assets USING btree (is_mock);


--
-- TOC entry 4001 (class 1259 OID 20585)
-- Name: ix_assets_mapping_status; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_assets_mapping_status ON migration.assets USING btree (mapping_status);


--
-- TOC entry 4002 (class 1259 OID 20586)
-- Name: ix_assets_migration_status; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_assets_migration_status ON migration.assets USING btree (migration_status);


--
-- TOC entry 4003 (class 1259 OID 20587)
-- Name: ix_assets_name; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_assets_name ON migration.assets USING btree (name);


--
-- TOC entry 4004 (class 1259 OID 20588)
-- Name: ix_assets_session_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_assets_session_id ON migration.assets USING btree (session_id);


--
-- TOC entry 4005 (class 1259 OID 20589)
-- Name: ix_assets_status; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_assets_status ON migration.assets USING btree (status);


--
-- TOC entry 3862 (class 1259 OID 19911)
-- Name: ix_client_access_client_account_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_client_access_client_account_id ON migration.client_access USING btree (client_account_id);


--
-- TOC entry 3863 (class 1259 OID 19912)
-- Name: ix_client_access_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_client_access_id ON migration.client_access USING btree (id);


--
-- TOC entry 3864 (class 1259 OID 19913)
-- Name: ix_client_access_is_active; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_client_access_is_active ON migration.client_access USING btree (is_active);


--
-- TOC entry 3865 (class 1259 OID 19914)
-- Name: ix_client_access_user_profile_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_client_access_user_profile_id ON migration.client_access USING btree (user_profile_id);


--
-- TOC entry 3844 (class 1259 OID 19828)
-- Name: ix_client_accounts_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_client_accounts_id ON migration.client_accounts USING btree (id);


--
-- TOC entry 3845 (class 1259 OID 19829)
-- Name: ix_client_accounts_is_active; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_client_accounts_is_active ON migration.client_accounts USING btree (is_active);


--
-- TOC entry 3846 (class 1259 OID 19830)
-- Name: ix_client_accounts_is_mock; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_client_accounts_is_mock ON migration.client_accounts USING btree (is_mock);


--
-- TOC entry 3847 (class 1259 OID 19831)
-- Name: ix_client_accounts_slug; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE UNIQUE INDEX ix_client_accounts_slug ON migration.client_accounts USING btree (slug);


--
-- TOC entry 3892 (class 1259 OID 20028)
-- Name: ix_cmdb_sixr_analyses_client_account_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_cmdb_sixr_analyses_client_account_id ON migration.cmdb_sixr_analyses USING btree (client_account_id);


--
-- TOC entry 3893 (class 1259 OID 20029)
-- Name: ix_cmdb_sixr_analyses_engagement_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_cmdb_sixr_analyses_engagement_id ON migration.cmdb_sixr_analyses USING btree (engagement_id);


--
-- TOC entry 3894 (class 1259 OID 20030)
-- Name: ix_cmdb_sixr_analyses_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_cmdb_sixr_analyses_id ON migration.cmdb_sixr_analyses USING btree (id);


--
-- TOC entry 3895 (class 1259 OID 20031)
-- Name: ix_cmdb_sixr_analyses_is_mock; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_cmdb_sixr_analyses_is_mock ON migration.cmdb_sixr_analyses USING btree (is_mock);


--
-- TOC entry 3896 (class 1259 OID 20032)
-- Name: ix_cmdb_sixr_analyses_status; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_cmdb_sixr_analyses_status ON migration.cmdb_sixr_analyses USING btree (status);


--
-- TOC entry 3850 (class 1259 OID 19847)
-- Name: ix_crewai_flow_state_extensions_flow_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_crewai_flow_state_extensions_flow_id ON migration.crewai_flow_state_extensions USING btree (flow_id);


--
-- TOC entry 3851 (class 1259 OID 19848)
-- Name: ix_crewai_flow_state_extensions_session_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_crewai_flow_state_extensions_session_id ON migration.crewai_flow_state_extensions USING btree (session_id);


--
-- TOC entry 3852 (class 1259 OID 19849)
-- Name: ix_crewai_flow_state_extensions_updated_at; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_crewai_flow_state_extensions_updated_at ON migration.crewai_flow_state_extensions USING btree (updated_at);


--
-- TOC entry 3853 (class 1259 OID 19850)
-- Name: ix_crewai_flow_state_extensions_workflow_state_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_crewai_flow_state_extensions_workflow_state_id ON migration.crewai_flow_state_extensions USING btree (workflow_state_id);


--
-- TOC entry 3899 (class 1259 OID 20063)
-- Name: ix_data_import_sessions_client_account_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_data_import_sessions_client_account_id ON migration.data_import_sessions USING btree (client_account_id);


--
-- TOC entry 3900 (class 1259 OID 20064)
-- Name: ix_data_import_sessions_engagement_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_data_import_sessions_engagement_id ON migration.data_import_sessions USING btree (engagement_id);


--
-- TOC entry 3901 (class 1259 OID 20065)
-- Name: ix_data_import_sessions_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_data_import_sessions_id ON migration.data_import_sessions USING btree (id);


--
-- TOC entry 3902 (class 1259 OID 20066)
-- Name: ix_data_import_sessions_is_default; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_data_import_sessions_is_default ON migration.data_import_sessions USING btree (is_default);


--
-- TOC entry 3903 (class 1259 OID 20067)
-- Name: ix_data_import_sessions_is_mock; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_data_import_sessions_is_mock ON migration.data_import_sessions USING btree (is_mock);


--
-- TOC entry 3904 (class 1259 OID 20068)
-- Name: ix_data_import_sessions_session_name; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_data_import_sessions_session_name ON migration.data_import_sessions USING btree (session_name);


--
-- TOC entry 3905 (class 1259 OID 20069)
-- Name: ix_data_import_sessions_status; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_data_import_sessions_status ON migration.data_import_sessions USING btree (status);


--
-- TOC entry 3908 (class 1259 OID 20094)
-- Name: ix_engagement_access_engagement_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_engagement_access_engagement_id ON migration.engagement_access USING btree (engagement_id);


--
-- TOC entry 3909 (class 1259 OID 20095)
-- Name: ix_engagement_access_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_engagement_access_id ON migration.engagement_access USING btree (id);


--
-- TOC entry 3910 (class 1259 OID 20096)
-- Name: ix_engagement_access_is_active; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_engagement_access_is_active ON migration.engagement_access USING btree (is_active);


--
-- TOC entry 3911 (class 1259 OID 20097)
-- Name: ix_engagement_access_user_profile_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_engagement_access_user_profile_id ON migration.engagement_access USING btree (user_profile_id);


--
-- TOC entry 3870 (class 1259 OID 19955)
-- Name: ix_engagements_client_account_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_engagements_client_account_id ON migration.engagements USING btree (client_account_id);


--
-- TOC entry 3871 (class 1259 OID 19956)
-- Name: ix_engagements_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_engagements_id ON migration.engagements USING btree (id);


--
-- TOC entry 3872 (class 1259 OID 19957)
-- Name: ix_engagements_is_active; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_engagements_is_active ON migration.engagements USING btree (is_active);


--
-- TOC entry 3873 (class 1259 OID 19958)
-- Name: ix_engagements_is_mock; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_engagements_is_mock ON migration.engagements USING btree (is_mock);


--
-- TOC entry 3874 (class 1259 OID 19959)
-- Name: ix_engagements_status; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_engagements_status ON migration.engagements USING btree (status);


--
-- TOC entry 3914 (class 1259 OID 20121)
-- Name: ix_enhanced_access_audit_log_action_type; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_enhanced_access_audit_log_action_type ON migration.enhanced_access_audit_log USING btree (action_type);


--
-- TOC entry 3915 (class 1259 OID 20122)
-- Name: ix_enhanced_access_audit_log_created_at; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_enhanced_access_audit_log_created_at ON migration.enhanced_access_audit_log USING btree (created_at);


--
-- TOC entry 3916 (class 1259 OID 20123)
-- Name: ix_enhanced_access_audit_log_user_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_enhanced_access_audit_log_user_id ON migration.enhanced_access_audit_log USING btree (user_id);


--
-- TOC entry 3919 (class 1259 OID 20158)
-- Name: ix_enhanced_user_profiles_data_scope; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_enhanced_user_profiles_data_scope ON migration.enhanced_user_profiles USING btree (data_scope);


--
-- TOC entry 3920 (class 1259 OID 20159)
-- Name: ix_enhanced_user_profiles_is_deleted; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_enhanced_user_profiles_is_deleted ON migration.enhanced_user_profiles USING btree (is_deleted);


--
-- TOC entry 3921 (class 1259 OID 20160)
-- Name: ix_enhanced_user_profiles_role_level; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_enhanced_user_profiles_role_level ON migration.enhanced_user_profiles USING btree (role_level);


--
-- TOC entry 3922 (class 1259 OID 20161)
-- Name: ix_enhanced_user_profiles_status; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_enhanced_user_profiles_status ON migration.enhanced_user_profiles USING btree (status);


--
-- TOC entry 3925 (class 1259 OID 20180)
-- Name: ix_feedback_feedback_type; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_feedback_feedback_type ON migration.feedback USING btree (feedback_type);


--
-- TOC entry 3926 (class 1259 OID 20181)
-- Name: ix_feedback_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_feedback_id ON migration.feedback USING btree (id);


--
-- TOC entry 3927 (class 1259 OID 20182)
-- Name: ix_feedback_page; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_feedback_page ON migration.feedback USING btree (page);


--
-- TOC entry 3930 (class 1259 OID 20201)
-- Name: ix_feedback_summaries_feedback_type; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_feedback_summaries_feedback_type ON migration.feedback_summaries USING btree (feedback_type);


--
-- TOC entry 3931 (class 1259 OID 20202)
-- Name: ix_feedback_summaries_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_feedback_summaries_id ON migration.feedback_summaries USING btree (id);


--
-- TOC entry 3932 (class 1259 OID 20203)
-- Name: ix_feedback_summaries_page; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_feedback_summaries_page ON migration.feedback_summaries USING btree (page);


--
-- TOC entry 3801 (class 1259 OID 19687)
-- Name: ix_flow_deletion_audit_client_account_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_flow_deletion_audit_client_account_id ON migration.flow_deletion_audit USING btree (client_account_id);


--
-- TOC entry 3802 (class 1259 OID 19688)
-- Name: ix_flow_deletion_audit_deleted_at; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_flow_deletion_audit_deleted_at ON migration.flow_deletion_audit USING btree (deleted_at);


--
-- TOC entry 3803 (class 1259 OID 19689)
-- Name: ix_flow_deletion_audit_deletion_type; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_flow_deletion_audit_deletion_type ON migration.flow_deletion_audit USING btree (deletion_type);


--
-- TOC entry 3804 (class 1259 OID 19690)
-- Name: ix_flow_deletion_audit_engagement_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_flow_deletion_audit_engagement_id ON migration.flow_deletion_audit USING btree (engagement_id);


--
-- TOC entry 3805 (class 1259 OID 19691)
-- Name: ix_flow_deletion_audit_session_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_flow_deletion_audit_session_id ON migration.flow_deletion_audit USING btree (session_id);


--
-- TOC entry 3952 (class 1259 OID 20272)
-- Name: ix_mapping_learning_patterns_engagement_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_mapping_learning_patterns_engagement_id ON migration.mapping_learning_patterns USING btree (engagement_id);


--
-- TOC entry 3953 (class 1259 OID 20273)
-- Name: ix_mapping_learning_patterns_source_column; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_mapping_learning_patterns_source_column ON migration.mapping_learning_patterns USING btree (source_column);


--
-- TOC entry 3954 (class 1259 OID 20274)
-- Name: ix_mapping_learning_patterns_target_column; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_mapping_learning_patterns_target_column ON migration.mapping_learning_patterns USING btree (target_column);


--
-- TOC entry 3854 (class 1259 OID 19866)
-- Name: ix_migration_logs_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_migration_logs_id ON migration.migration_logs USING btree (id);


--
-- TOC entry 3957 (class 1259 OID 20298)
-- Name: ix_migration_waves_client_account_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_migration_waves_client_account_id ON migration.migration_waves USING btree (client_account_id);


--
-- TOC entry 3958 (class 1259 OID 20299)
-- Name: ix_migration_waves_engagement_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_migration_waves_engagement_id ON migration.migration_waves USING btree (engagement_id);


--
-- TOC entry 3959 (class 1259 OID 20300)
-- Name: ix_migration_waves_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_migration_waves_id ON migration.migration_waves USING btree (id);


--
-- TOC entry 3960 (class 1259 OID 20301)
-- Name: ix_migration_waves_is_mock; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_migration_waves_is_mock ON migration.migration_waves USING btree (is_mock);


--
-- TOC entry 3961 (class 1259 OID 20302)
-- Name: ix_migration_waves_status; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_migration_waves_status ON migration.migration_waves USING btree (status);


--
-- TOC entry 3962 (class 1259 OID 20303)
-- Name: ix_migration_waves_wave_number; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_migration_waves_wave_number ON migration.migration_waves USING btree (wave_number);


--
-- TOC entry 3812 (class 1259 OID 19743)
-- Name: ix_migrations_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_migrations_id ON migration.migrations USING btree (id);


--
-- TOC entry 3813 (class 1259 OID 19744)
-- Name: ix_migrations_name; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_migrations_name ON migration.migrations USING btree (name);


--
-- TOC entry 3816 (class 1259 OID 19751)
-- Name: ix_role_permissions_role_level; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_role_permissions_role_level ON migration.role_permissions USING btree (role_level);


--
-- TOC entry 3965 (class 1259 OID 20356)
-- Name: ix_sixr_analyses_client_account_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_sixr_analyses_client_account_id ON migration.sixr_analyses USING btree (client_account_id);


--
-- TOC entry 3966 (class 1259 OID 20357)
-- Name: ix_sixr_analyses_engagement_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_sixr_analyses_engagement_id ON migration.sixr_analyses USING btree (engagement_id);


--
-- TOC entry 3967 (class 1259 OID 20358)
-- Name: ix_sixr_analyses_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_sixr_analyses_id ON migration.sixr_analyses USING btree (id);


--
-- TOC entry 3968 (class 1259 OID 20359)
-- Name: ix_sixr_analyses_name; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_sixr_analyses_name ON migration.sixr_analyses USING btree (name);


--
-- TOC entry 4008 (class 1259 OID 20632)
-- Name: ix_sixr_analysis_parameters_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_sixr_analysis_parameters_id ON migration.sixr_analysis_parameters USING btree (id);


--
-- TOC entry 4011 (class 1259 OID 20646)
-- Name: ix_sixr_iterations_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_sixr_iterations_id ON migration.sixr_iterations USING btree (id);


--
-- TOC entry 3819 (class 1259 OID 19760)
-- Name: ix_sixr_parameters_parameter_key; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE UNIQUE INDEX ix_sixr_parameters_parameter_key ON migration.sixr_parameters USING btree (parameter_key);


--
-- TOC entry 4014 (class 1259 OID 20665)
-- Name: ix_sixr_question_responses_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_sixr_question_responses_id ON migration.sixr_question_responses USING btree (id);


--
-- TOC entry 3822 (class 1259 OID 19783)
-- Name: ix_sixr_questions_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_sixr_questions_id ON migration.sixr_questions USING btree (id);


--
-- TOC entry 3823 (class 1259 OID 19784)
-- Name: ix_sixr_questions_question_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE UNIQUE INDEX ix_sixr_questions_question_id ON migration.sixr_questions USING btree (question_id);


--
-- TOC entry 4017 (class 1259 OID 20678)
-- Name: ix_sixr_recommendations_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_sixr_recommendations_id ON migration.sixr_recommendations USING btree (id);


--
-- TOC entry 3971 (class 1259 OID 20394)
-- Name: ix_soft_deleted_items_item_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_soft_deleted_items_item_id ON migration.soft_deleted_items USING btree (item_id);


--
-- TOC entry 3972 (class 1259 OID 20395)
-- Name: ix_soft_deleted_items_item_type; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_soft_deleted_items_item_type ON migration.soft_deleted_items USING btree (item_type);


--
-- TOC entry 3973 (class 1259 OID 20396)
-- Name: ix_soft_deleted_items_status; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_soft_deleted_items_status ON migration.soft_deleted_items USING btree (status);


--
-- TOC entry 3875 (class 1259 OID 19973)
-- Name: ix_tags_category; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_tags_category ON migration.tags USING btree (category);


--
-- TOC entry 3876 (class 1259 OID 19974)
-- Name: ix_tags_client_account_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_tags_client_account_id ON migration.tags USING btree (client_account_id);


--
-- TOC entry 3877 (class 1259 OID 19975)
-- Name: ix_tags_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_tags_id ON migration.tags USING btree (id);


--
-- TOC entry 3878 (class 1259 OID 19976)
-- Name: ix_tags_is_active; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_tags_is_active ON migration.tags USING btree (is_active);


--
-- TOC entry 3879 (class 1259 OID 19977)
-- Name: ix_tags_is_mock; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_tags_is_mock ON migration.tags USING btree (is_mock);


--
-- TOC entry 3880 (class 1259 OID 19978)
-- Name: ix_tags_name; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE UNIQUE INDEX ix_tags_name ON migration.tags USING btree (name);


--
-- TOC entry 3885 (class 1259 OID 20002)
-- Name: ix_user_account_associations_client_account_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_user_account_associations_client_account_id ON migration.user_account_associations USING btree (client_account_id);


--
-- TOC entry 3886 (class 1259 OID 20003)
-- Name: ix_user_account_associations_is_mock; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_user_account_associations_is_mock ON migration.user_account_associations USING btree (is_mock);


--
-- TOC entry 3887 (class 1259 OID 20004)
-- Name: ix_user_account_associations_user_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_user_account_associations_user_id ON migration.user_account_associations USING btree (user_id);


--
-- TOC entry 3857 (class 1259 OID 19886)
-- Name: ix_user_profiles_status; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_user_profiles_status ON migration.user_profiles USING btree (status);


--
-- TOC entry 3976 (class 1259 OID 20426)
-- Name: ix_user_roles_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_user_roles_id ON migration.user_roles USING btree (id);


--
-- TOC entry 3977 (class 1259 OID 20427)
-- Name: ix_user_roles_is_active; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_user_roles_is_active ON migration.user_roles USING btree (is_active);


--
-- TOC entry 3978 (class 1259 OID 20428)
-- Name: ix_user_roles_user_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_user_roles_user_id ON migration.user_roles USING btree (user_id);


--
-- TOC entry 3826 (class 1259 OID 19793)
-- Name: ix_users_email; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_email ON migration.users USING btree (email);


--
-- TOC entry 3827 (class 1259 OID 19794)
-- Name: ix_users_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_users_id ON migration.users USING btree (id);


--
-- TOC entry 3828 (class 1259 OID 19795)
-- Name: ix_users_is_active; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_users_is_active ON migration.users USING btree (is_active);


--
-- TOC entry 3829 (class 1259 OID 19796)
-- Name: ix_users_is_mock; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_users_is_mock ON migration.users USING btree (is_mock);


--
-- TOC entry 3981 (class 1259 OID 20462)
-- Name: ix_wave_plans_client_account_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_wave_plans_client_account_id ON migration.wave_plans USING btree (client_account_id);


--
-- TOC entry 3982 (class 1259 OID 20463)
-- Name: ix_wave_plans_engagement_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_wave_plans_engagement_id ON migration.wave_plans USING btree (engagement_id);


--
-- TOC entry 3983 (class 1259 OID 20464)
-- Name: ix_wave_plans_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_wave_plans_id ON migration.wave_plans USING btree (id);


--
-- TOC entry 3832 (class 1259 OID 19807)
-- Name: ix_workflow_states_client_account_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_workflow_states_client_account_id ON migration.workflow_states USING btree (client_account_id);


--
-- TOC entry 3833 (class 1259 OID 19808)
-- Name: ix_workflow_states_current_phase; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_workflow_states_current_phase ON migration.workflow_states USING btree (current_phase);


--
-- TOC entry 3834 (class 1259 OID 19809)
-- Name: ix_workflow_states_engagement_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_workflow_states_engagement_id ON migration.workflow_states USING btree (engagement_id);


--
-- TOC entry 3835 (class 1259 OID 19810)
-- Name: ix_workflow_states_flow_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_workflow_states_flow_id ON migration.workflow_states USING btree (flow_id);


--
-- TOC entry 3836 (class 1259 OID 19811)
-- Name: ix_workflow_states_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_workflow_states_id ON migration.workflow_states USING btree (id);


--
-- TOC entry 3837 (class 1259 OID 19812)
-- Name: ix_workflow_states_session_id; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_workflow_states_session_id ON migration.workflow_states USING btree (session_id);


--
-- TOC entry 3838 (class 1259 OID 19813)
-- Name: ix_workflow_states_status; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_workflow_states_status ON migration.workflow_states USING btree (status);


--
-- TOC entry 3839 (class 1259 OID 19814)
-- Name: ix_workflow_states_workflow_type; Type: INDEX; Schema: migration; Owner: postgres
--

CREATE INDEX ix_workflow_states_workflow_type ON migration.workflow_states USING btree (workflow_type);


--
-- TOC entry 4111 (class 2606 OID 20473)
-- Name: access_audit_log access_audit_log_client_account_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.access_audit_log
    ADD CONSTRAINT access_audit_log_client_account_id_fkey FOREIGN KEY (client_account_id) REFERENCES migration.client_accounts(id);


--
-- TOC entry 4112 (class 2606 OID 20478)
-- Name: access_audit_log access_audit_log_engagement_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.access_audit_log
    ADD CONSTRAINT access_audit_log_engagement_id_fkey FOREIGN KEY (engagement_id) REFERENCES migration.engagements(id);


--
-- TOC entry 4113 (class 2606 OID 20483)
-- Name: access_audit_log access_audit_log_session_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.access_audit_log
    ADD CONSTRAINT access_audit_log_session_id_fkey FOREIGN KEY (session_id) REFERENCES migration.data_import_sessions(id);


--
-- TOC entry 4114 (class 2606 OID 20488)
-- Name: access_audit_log access_audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.access_audit_log
    ADD CONSTRAINT access_audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES migration.users(id);


--
-- TOC entry 4131 (class 2606 OID 20718)
-- Name: assessments assessments_asset_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.assessments
    ADD CONSTRAINT assessments_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES migration.assets(id);


--
-- TOC entry 4132 (class 2606 OID 20723)
-- Name: assessments assessments_client_account_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.assessments
    ADD CONSTRAINT assessments_client_account_id_fkey FOREIGN KEY (client_account_id) REFERENCES migration.client_accounts(id) ON DELETE CASCADE;


--
-- TOC entry 4133 (class 2606 OID 20728)
-- Name: assessments assessments_engagement_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.assessments
    ADD CONSTRAINT assessments_engagement_id_fkey FOREIGN KEY (engagement_id) REFERENCES migration.engagements(id) ON DELETE CASCADE;


--
-- TOC entry 4134 (class 2606 OID 20733)
-- Name: assessments assessments_migration_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.assessments
    ADD CONSTRAINT assessments_migration_id_fkey FOREIGN KEY (migration_id) REFERENCES migration.migrations(id);


--
-- TOC entry 4135 (class 2606 OID 20749)
-- Name: asset_dependencies asset_dependencies_asset_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.asset_dependencies
    ADD CONSTRAINT asset_dependencies_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES migration.assets(id) ON DELETE CASCADE;


--
-- TOC entry 4136 (class 2606 OID 20754)
-- Name: asset_dependencies asset_dependencies_depends_on_asset_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.asset_dependencies
    ADD CONSTRAINT asset_dependencies_depends_on_asset_id_fkey FOREIGN KEY (depends_on_asset_id) REFERENCES migration.assets(id) ON DELETE CASCADE;


--
-- TOC entry 4137 (class 2606 OID 20767)
-- Name: asset_embeddings asset_embeddings_asset_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.asset_embeddings
    ADD CONSTRAINT asset_embeddings_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES migration.assets(id) ON DELETE CASCADE;


--
-- TOC entry 4138 (class 2606 OID 20772)
-- Name: asset_embeddings asset_embeddings_client_account_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.asset_embeddings
    ADD CONSTRAINT asset_embeddings_client_account_id_fkey FOREIGN KEY (client_account_id) REFERENCES migration.client_accounts(id) ON DELETE CASCADE;


--
-- TOC entry 4139 (class 2606 OID 20777)
-- Name: asset_embeddings asset_embeddings_engagement_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.asset_embeddings
    ADD CONSTRAINT asset_embeddings_engagement_id_fkey FOREIGN KEY (engagement_id) REFERENCES migration.engagements(id) ON DELETE CASCADE;


--
-- TOC entry 4140 (class 2606 OID 20793)
-- Name: asset_tags asset_tags_asset_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.asset_tags
    ADD CONSTRAINT asset_tags_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES migration.assets(id) ON DELETE CASCADE;


--
-- TOC entry 4141 (class 2606 OID 20798)
-- Name: asset_tags asset_tags_assigned_by_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.asset_tags
    ADD CONSTRAINT asset_tags_assigned_by_fkey FOREIGN KEY (assigned_by) REFERENCES migration.users(id);


--
-- TOC entry 4142 (class 2606 OID 20803)
-- Name: asset_tags asset_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.asset_tags
    ADD CONSTRAINT asset_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES migration.tags(id) ON DELETE CASCADE;


--
-- TOC entry 4143 (class 2606 OID 20808)
-- Name: asset_tags asset_tags_validated_by_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.asset_tags
    ADD CONSTRAINT asset_tags_validated_by_fkey FOREIGN KEY (validated_by) REFERENCES migration.users(id);


--
-- TOC entry 4115 (class 2606 OID 20543)
-- Name: assets assets_client_account_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.assets
    ADD CONSTRAINT assets_client_account_id_fkey FOREIGN KEY (client_account_id) REFERENCES migration.client_accounts(id) ON DELETE CASCADE;


--
-- TOC entry 4116 (class 2606 OID 20548)
-- Name: assets assets_created_by_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.assets
    ADD CONSTRAINT assets_created_by_fkey FOREIGN KEY (created_by) REFERENCES migration.users(id);


--
-- TOC entry 4117 (class 2606 OID 20553)
-- Name: assets assets_engagement_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.assets
    ADD CONSTRAINT assets_engagement_id_fkey FOREIGN KEY (engagement_id) REFERENCES migration.engagements(id) ON DELETE CASCADE;


--
-- TOC entry 4118 (class 2606 OID 20558)
-- Name: assets assets_imported_by_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.assets
    ADD CONSTRAINT assets_imported_by_fkey FOREIGN KEY (imported_by) REFERENCES migration.users(id);


--
-- TOC entry 4119 (class 2606 OID 20563)
-- Name: assets assets_migration_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.assets
    ADD CONSTRAINT assets_migration_id_fkey FOREIGN KEY (migration_id) REFERENCES migration.migrations(id);


--
-- TOC entry 4120 (class 2606 OID 20568)
-- Name: assets assets_session_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.assets
    ADD CONSTRAINT assets_session_id_fkey FOREIGN KEY (session_id) REFERENCES migration.data_import_sessions(id) ON DELETE CASCADE;


--
-- TOC entry 4121 (class 2606 OID 20573)
-- Name: assets assets_updated_by_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.assets
    ADD CONSTRAINT assets_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES migration.users(id);


--
-- TOC entry 4054 (class 2606 OID 19896)
-- Name: client_access client_access_client_account_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.client_access
    ADD CONSTRAINT client_access_client_account_id_fkey FOREIGN KEY (client_account_id) REFERENCES migration.client_accounts(id) ON DELETE CASCADE;


--
-- TOC entry 4055 (class 2606 OID 19901)
-- Name: client_access client_access_granted_by_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.client_access
    ADD CONSTRAINT client_access_granted_by_fkey FOREIGN KEY (granted_by) REFERENCES migration.users(id);


--
-- TOC entry 4056 (class 2606 OID 19906)
-- Name: client_access client_access_user_profile_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.client_access
    ADD CONSTRAINT client_access_user_profile_id_fkey FOREIGN KEY (user_profile_id) REFERENCES migration.user_profiles(user_id) ON DELETE CASCADE;


--
-- TOC entry 4049 (class 2606 OID 19823)
-- Name: client_accounts client_accounts_created_by_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.client_accounts
    ADD CONSTRAINT client_accounts_created_by_fkey FOREIGN KEY (created_by) REFERENCES migration.users(id);


--
-- TOC entry 4066 (class 2606 OID 20013)
-- Name: cmdb_sixr_analyses cmdb_sixr_analyses_client_account_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.cmdb_sixr_analyses
    ADD CONSTRAINT cmdb_sixr_analyses_client_account_id_fkey FOREIGN KEY (client_account_id) REFERENCES migration.client_accounts(id) ON DELETE CASCADE;


--
-- TOC entry 4067 (class 2606 OID 20018)
-- Name: cmdb_sixr_analyses cmdb_sixr_analyses_created_by_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.cmdb_sixr_analyses
    ADD CONSTRAINT cmdb_sixr_analyses_created_by_fkey FOREIGN KEY (created_by) REFERENCES migration.users(id);


--
-- TOC entry 4068 (class 2606 OID 20023)
-- Name: cmdb_sixr_analyses cmdb_sixr_analyses_engagement_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.cmdb_sixr_analyses
    ADD CONSTRAINT cmdb_sixr_analyses_engagement_id_fkey FOREIGN KEY (engagement_id) REFERENCES migration.engagements(id) ON DELETE CASCADE;


--
-- TOC entry 4050 (class 2606 OID 19842)
-- Name: crewai_flow_state_extensions crewai_flow_state_extensions_workflow_state_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.crewai_flow_state_extensions
    ADD CONSTRAINT crewai_flow_state_extensions_workflow_state_id_fkey FOREIGN KEY (workflow_state_id) REFERENCES migration.workflow_states(id) ON DELETE CASCADE;


--
-- TOC entry 4057 (class 2606 OID 19922)
-- Name: custom_target_fields custom_target_fields_client_account_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.custom_target_fields
    ADD CONSTRAINT custom_target_fields_client_account_id_fkey FOREIGN KEY (client_account_id) REFERENCES migration.client_accounts(id);


--
-- TOC entry 4058 (class 2606 OID 19927)
-- Name: custom_target_fields custom_target_fields_created_by_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.custom_target_fields
    ADD CONSTRAINT custom_target_fields_created_by_fkey FOREIGN KEY (created_by) REFERENCES migration.users(id);


--
-- TOC entry 4069 (class 2606 OID 20043)
-- Name: data_import_sessions data_import_sessions_client_account_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.data_import_sessions
    ADD CONSTRAINT data_import_sessions_client_account_id_fkey FOREIGN KEY (client_account_id) REFERENCES migration.client_accounts(id) ON DELETE CASCADE;


--
-- TOC entry 4070 (class 2606 OID 20048)
-- Name: data_import_sessions data_import_sessions_created_by_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.data_import_sessions
    ADD CONSTRAINT data_import_sessions_created_by_fkey FOREIGN KEY (created_by) REFERENCES migration.users(id);


--
-- TOC entry 4071 (class 2606 OID 20053)
-- Name: data_import_sessions data_import_sessions_engagement_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.data_import_sessions
    ADD CONSTRAINT data_import_sessions_engagement_id_fkey FOREIGN KEY (engagement_id) REFERENCES migration.engagements(id) ON DELETE CASCADE;


--
-- TOC entry 4072 (class 2606 OID 20058)
-- Name: data_import_sessions data_import_sessions_parent_session_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.data_import_sessions
    ADD CONSTRAINT data_import_sessions_parent_session_id_fkey FOREIGN KEY (parent_session_id) REFERENCES migration.data_import_sessions(id) ON DELETE SET NULL;


--
-- TOC entry 4122 (class 2606 OID 20599)
-- Name: data_imports data_imports_client_account_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.data_imports
    ADD CONSTRAINT data_imports_client_account_id_fkey FOREIGN KEY (client_account_id) REFERENCES migration.client_accounts(id) ON DELETE CASCADE;


--
-- TOC entry 4123 (class 2606 OID 20604)
-- Name: data_imports data_imports_engagement_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.data_imports
    ADD CONSTRAINT data_imports_engagement_id_fkey FOREIGN KEY (engagement_id) REFERENCES migration.engagements(id) ON DELETE CASCADE;


--
-- TOC entry 4124 (class 2606 OID 20609)
-- Name: data_imports data_imports_imported_by_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.data_imports
    ADD CONSTRAINT data_imports_imported_by_fkey FOREIGN KEY (imported_by) REFERENCES migration.users(id);


--
-- TOC entry 4125 (class 2606 OID 20614)
-- Name: data_imports data_imports_session_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.data_imports
    ADD CONSTRAINT data_imports_session_id_fkey FOREIGN KEY (session_id) REFERENCES migration.data_import_sessions(id) ON DELETE CASCADE;


--
-- TOC entry 4153 (class 2606 OID 20900)
-- Name: data_quality_issues data_quality_issues_data_import_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.data_quality_issues
    ADD CONSTRAINT data_quality_issues_data_import_id_fkey FOREIGN KEY (data_import_id) REFERENCES migration.data_imports(id) ON DELETE CASCADE;


--
-- TOC entry 4154 (class 2606 OID 20905)
-- Name: data_quality_issues data_quality_issues_raw_record_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.data_quality_issues
    ADD CONSTRAINT data_quality_issues_raw_record_id_fkey FOREIGN KEY (raw_record_id) REFERENCES migration.raw_import_records(id);


--
-- TOC entry 4155 (class 2606 OID 20910)
-- Name: data_quality_issues data_quality_issues_resolved_by_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.data_quality_issues
    ADD CONSTRAINT data_quality_issues_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES migration.users(id);


--
-- TOC entry 4073 (class 2606 OID 20079)
-- Name: engagement_access engagement_access_engagement_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.engagement_access
    ADD CONSTRAINT engagement_access_engagement_id_fkey FOREIGN KEY (engagement_id) REFERENCES migration.engagements(id) ON DELETE CASCADE;


--
-- TOC entry 4074 (class 2606 OID 20084)
-- Name: engagement_access engagement_access_granted_by_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.engagement_access
    ADD CONSTRAINT engagement_access_granted_by_fkey FOREIGN KEY (granted_by) REFERENCES migration.users(id);


--
-- TOC entry 4075 (class 2606 OID 20089)
-- Name: engagement_access engagement_access_user_profile_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.engagement_access
    ADD CONSTRAINT engagement_access_user_profile_id_fkey FOREIGN KEY (user_profile_id) REFERENCES migration.user_profiles(user_id) ON DELETE CASCADE;


--
-- TOC entry 4059 (class 2606 OID 19940)
-- Name: engagements engagements_client_account_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.engagements
    ADD CONSTRAINT engagements_client_account_id_fkey FOREIGN KEY (client_account_id) REFERENCES migration.client_accounts(id) ON DELETE CASCADE;


--
-- TOC entry 4060 (class 2606 OID 19945)
-- Name: engagements engagements_created_by_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.engagements
    ADD CONSTRAINT engagements_created_by_fkey FOREIGN KEY (created_by) REFERENCES migration.users(id);


--
-- TOC entry 4061 (class 2606 OID 19950)
-- Name: engagements engagements_engagement_lead_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.engagements
    ADD CONSTRAINT engagements_engagement_lead_id_fkey FOREIGN KEY (engagement_lead_id) REFERENCES migration.users(id);


--
-- TOC entry 4076 (class 2606 OID 20106)
-- Name: enhanced_access_audit_log enhanced_access_audit_log_client_account_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.enhanced_access_audit_log
    ADD CONSTRAINT enhanced_access_audit_log_client_account_id_fkey FOREIGN KEY (client_account_id) REFERENCES migration.client_accounts(id);


--
-- TOC entry 4077 (class 2606 OID 20111)
-- Name: enhanced_access_audit_log enhanced_access_audit_log_engagement_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.enhanced_access_audit_log
    ADD CONSTRAINT enhanced_access_audit_log_engagement_id_fkey FOREIGN KEY (engagement_id) REFERENCES migration.engagements(id);


--
-- TOC entry 4078 (class 2606 OID 20116)
-- Name: enhanced_access_audit_log enhanced_access_audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.enhanced_access_audit_log
    ADD CONSTRAINT enhanced_access_audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES migration.users(id);


--
-- TOC entry 4079 (class 2606 OID 20133)
-- Name: enhanced_user_profiles enhanced_user_profiles_approved_by_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.enhanced_user_profiles
    ADD CONSTRAINT enhanced_user_profiles_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES migration.users(id);


--
-- TOC entry 4080 (class 2606 OID 20138)
-- Name: enhanced_user_profiles enhanced_user_profiles_deleted_by_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.enhanced_user_profiles
    ADD CONSTRAINT enhanced_user_profiles_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES migration.users(id);


--
-- TOC entry 4081 (class 2606 OID 20143)
-- Name: enhanced_user_profiles enhanced_user_profiles_scope_client_account_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.enhanced_user_profiles
    ADD CONSTRAINT enhanced_user_profiles_scope_client_account_id_fkey FOREIGN KEY (scope_client_account_id) REFERENCES migration.client_accounts(id);


--
-- TOC entry 4082 (class 2606 OID 20148)
-- Name: enhanced_user_profiles enhanced_user_profiles_scope_engagement_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.enhanced_user_profiles
    ADD CONSTRAINT enhanced_user_profiles_scope_engagement_id_fkey FOREIGN KEY (scope_engagement_id) REFERENCES migration.engagements(id);


--
-- TOC entry 4083 (class 2606 OID 20153)
-- Name: enhanced_user_profiles enhanced_user_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.enhanced_user_profiles
    ADD CONSTRAINT enhanced_user_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES migration.users(id) ON DELETE CASCADE;


--
-- TOC entry 4084 (class 2606 OID 20170)
-- Name: feedback feedback_client_account_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.feedback
    ADD CONSTRAINT feedback_client_account_id_fkey FOREIGN KEY (client_account_id) REFERENCES migration.client_accounts(id) ON DELETE CASCADE;


--
-- TOC entry 4085 (class 2606 OID 20175)
-- Name: feedback feedback_engagement_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.feedback
    ADD CONSTRAINT feedback_engagement_id_fkey FOREIGN KEY (engagement_id) REFERENCES migration.engagements(id) ON DELETE CASCADE;


--
-- TOC entry 4086 (class 2606 OID 20191)
-- Name: feedback_summaries feedback_summaries_client_account_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.feedback_summaries
    ADD CONSTRAINT feedback_summaries_client_account_id_fkey FOREIGN KEY (client_account_id) REFERENCES migration.client_accounts(id) ON DELETE CASCADE;


--
-- TOC entry 4087 (class 2606 OID 20196)
-- Name: feedback_summaries feedback_summaries_engagement_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.feedback_summaries
    ADD CONSTRAINT feedback_summaries_engagement_id_fkey FOREIGN KEY (engagement_id) REFERENCES migration.engagements(id) ON DELETE CASCADE;


--
-- TOC entry 4144 (class 2606 OID 20824)
-- Name: import_field_mappings import_field_mappings_data_import_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.import_field_mappings
    ADD CONSTRAINT import_field_mappings_data_import_id_fkey FOREIGN KEY (data_import_id) REFERENCES migration.data_imports(id) ON DELETE CASCADE;


--
-- TOC entry 4145 (class 2606 OID 20829)
-- Name: import_field_mappings import_field_mappings_validated_by_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.import_field_mappings
    ADD CONSTRAINT import_field_mappings_validated_by_fkey FOREIGN KEY (validated_by) REFERENCES migration.users(id);


--
-- TOC entry 4146 (class 2606 OID 20842)
-- Name: import_processing_steps import_processing_steps_data_import_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.import_processing_steps
    ADD CONSTRAINT import_processing_steps_data_import_id_fkey FOREIGN KEY (data_import_id) REFERENCES migration.data_imports(id) ON DELETE CASCADE;


--
-- TOC entry 4088 (class 2606 OID 20213)
-- Name: llm_usage_logs llm_usage_logs_client_account_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.llm_usage_logs
    ADD CONSTRAINT llm_usage_logs_client_account_id_fkey FOREIGN KEY (client_account_id) REFERENCES migration.client_accounts(id);


--
-- TOC entry 4089 (class 2606 OID 20218)
-- Name: llm_usage_logs llm_usage_logs_engagement_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.llm_usage_logs
    ADD CONSTRAINT llm_usage_logs_engagement_id_fkey FOREIGN KEY (engagement_id) REFERENCES migration.engagements(id);


--
-- TOC entry 4090 (class 2606 OID 20244)
-- Name: llm_usage_summary llm_usage_summary_client_account_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.llm_usage_summary
    ADD CONSTRAINT llm_usage_summary_client_account_id_fkey FOREIGN KEY (client_account_id) REFERENCES migration.client_accounts(id);


--
-- TOC entry 4091 (class 2606 OID 20249)
-- Name: llm_usage_summary llm_usage_summary_engagement_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.llm_usage_summary
    ADD CONSTRAINT llm_usage_summary_engagement_id_fkey FOREIGN KEY (engagement_id) REFERENCES migration.engagements(id);


--
-- TOC entry 4092 (class 2606 OID 20267)
-- Name: mapping_learning_patterns mapping_learning_patterns_engagement_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.mapping_learning_patterns
    ADD CONSTRAINT mapping_learning_patterns_engagement_id_fkey FOREIGN KEY (engagement_id) REFERENCES migration.engagements(id);


--
-- TOC entry 4051 (class 2606 OID 19861)
-- Name: migration_logs migration_logs_migration_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.migration_logs
    ADD CONSTRAINT migration_logs_migration_id_fkey FOREIGN KEY (migration_id) REFERENCES migration.migrations(id);


--
-- TOC entry 4093 (class 2606 OID 20283)
-- Name: migration_waves migration_waves_client_account_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.migration_waves
    ADD CONSTRAINT migration_waves_client_account_id_fkey FOREIGN KEY (client_account_id) REFERENCES migration.client_accounts(id) ON DELETE CASCADE;


--
-- TOC entry 4094 (class 2606 OID 20288)
-- Name: migration_waves migration_waves_created_by_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.migration_waves
    ADD CONSTRAINT migration_waves_created_by_fkey FOREIGN KEY (created_by) REFERENCES migration.users(id);


--
-- TOC entry 4095 (class 2606 OID 20293)
-- Name: migration_waves migration_waves_engagement_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.migration_waves
    ADD CONSTRAINT migration_waves_engagement_id_fkey FOREIGN KEY (engagement_id) REFERENCES migration.engagements(id) ON DELETE CASCADE;


--
-- TOC entry 4147 (class 2606 OID 20855)
-- Name: raw_import_records raw_import_records_asset_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.raw_import_records
    ADD CONSTRAINT raw_import_records_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES migration.assets(id);


--
-- TOC entry 4148 (class 2606 OID 20860)
-- Name: raw_import_records raw_import_records_client_account_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.raw_import_records
    ADD CONSTRAINT raw_import_records_client_account_id_fkey FOREIGN KEY (client_account_id) REFERENCES migration.client_accounts(id);


--
-- TOC entry 4149 (class 2606 OID 20865)
-- Name: raw_import_records raw_import_records_data_import_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.raw_import_records
    ADD CONSTRAINT raw_import_records_data_import_id_fkey FOREIGN KEY (data_import_id) REFERENCES migration.data_imports(id) ON DELETE CASCADE;


--
-- TOC entry 4150 (class 2606 OID 20870)
-- Name: raw_import_records raw_import_records_engagement_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.raw_import_records
    ADD CONSTRAINT raw_import_records_engagement_id_fkey FOREIGN KEY (engagement_id) REFERENCES migration.engagements(id);


--
-- TOC entry 4151 (class 2606 OID 20875)
-- Name: raw_import_records raw_import_records_session_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.raw_import_records
    ADD CONSTRAINT raw_import_records_session_id_fkey FOREIGN KEY (session_id) REFERENCES migration.data_import_sessions(id);


--
-- TOC entry 4096 (class 2606 OID 20341)
-- Name: sixr_analyses sixr_analyses_client_account_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.sixr_analyses
    ADD CONSTRAINT sixr_analyses_client_account_id_fkey FOREIGN KEY (client_account_id) REFERENCES migration.client_accounts(id) ON DELETE CASCADE;


--
-- TOC entry 4097 (class 2606 OID 20346)
-- Name: sixr_analyses sixr_analyses_engagement_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.sixr_analyses
    ADD CONSTRAINT sixr_analyses_engagement_id_fkey FOREIGN KEY (engagement_id) REFERENCES migration.engagements(id) ON DELETE CASCADE;


--
-- TOC entry 4098 (class 2606 OID 20351)
-- Name: sixr_analyses sixr_analyses_migration_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.sixr_analyses
    ADD CONSTRAINT sixr_analyses_migration_id_fkey FOREIGN KEY (migration_id) REFERENCES migration.migrations(id);


--
-- TOC entry 4126 (class 2606 OID 20627)
-- Name: sixr_analysis_parameters sixr_analysis_parameters_analysis_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.sixr_analysis_parameters
    ADD CONSTRAINT sixr_analysis_parameters_analysis_id_fkey FOREIGN KEY (analysis_id) REFERENCES migration.sixr_analyses(id);


--
-- TOC entry 4127 (class 2606 OID 20641)
-- Name: sixr_iterations sixr_iterations_analysis_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.sixr_iterations
    ADD CONSTRAINT sixr_iterations_analysis_id_fkey FOREIGN KEY (analysis_id) REFERENCES migration.sixr_analyses(id);


--
-- TOC entry 4128 (class 2606 OID 20655)
-- Name: sixr_question_responses sixr_question_responses_analysis_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.sixr_question_responses
    ADD CONSTRAINT sixr_question_responses_analysis_id_fkey FOREIGN KEY (analysis_id) REFERENCES migration.sixr_analyses(id);


--
-- TOC entry 4129 (class 2606 OID 20660)
-- Name: sixr_question_responses sixr_question_responses_question_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.sixr_question_responses
    ADD CONSTRAINT sixr_question_responses_question_id_fkey FOREIGN KEY (question_id) REFERENCES migration.sixr_questions(question_id);


--
-- TOC entry 4130 (class 2606 OID 20673)
-- Name: sixr_recommendations sixr_recommendations_analysis_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.sixr_recommendations
    ADD CONSTRAINT sixr_recommendations_analysis_id_fkey FOREIGN KEY (analysis_id) REFERENCES migration.sixr_analyses(id);


--
-- TOC entry 4099 (class 2606 OID 20369)
-- Name: soft_deleted_items soft_deleted_items_client_account_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.soft_deleted_items
    ADD CONSTRAINT soft_deleted_items_client_account_id_fkey FOREIGN KEY (client_account_id) REFERENCES migration.client_accounts(id);


--
-- TOC entry 4100 (class 2606 OID 20374)
-- Name: soft_deleted_items soft_deleted_items_deleted_by_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.soft_deleted_items
    ADD CONSTRAINT soft_deleted_items_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES migration.users(id);


--
-- TOC entry 4101 (class 2606 OID 20379)
-- Name: soft_deleted_items soft_deleted_items_engagement_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.soft_deleted_items
    ADD CONSTRAINT soft_deleted_items_engagement_id_fkey FOREIGN KEY (engagement_id) REFERENCES migration.engagements(id);


--
-- TOC entry 4102 (class 2606 OID 20384)
-- Name: soft_deleted_items soft_deleted_items_purged_by_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.soft_deleted_items
    ADD CONSTRAINT soft_deleted_items_purged_by_fkey FOREIGN KEY (purged_by) REFERENCES migration.users(id);


--
-- TOC entry 4103 (class 2606 OID 20389)
-- Name: soft_deleted_items soft_deleted_items_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.soft_deleted_items
    ADD CONSTRAINT soft_deleted_items_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES migration.users(id);


--
-- TOC entry 4062 (class 2606 OID 19968)
-- Name: tags tags_client_account_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.tags
    ADD CONSTRAINT tags_client_account_id_fkey FOREIGN KEY (client_account_id) REFERENCES migration.client_accounts(id) ON DELETE CASCADE;


--
-- TOC entry 4063 (class 2606 OID 19987)
-- Name: user_account_associations user_account_associations_client_account_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.user_account_associations
    ADD CONSTRAINT user_account_associations_client_account_id_fkey FOREIGN KEY (client_account_id) REFERENCES migration.client_accounts(id) ON DELETE CASCADE;


--
-- TOC entry 4064 (class 2606 OID 19992)
-- Name: user_account_associations user_account_associations_created_by_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.user_account_associations
    ADD CONSTRAINT user_account_associations_created_by_fkey FOREIGN KEY (created_by) REFERENCES migration.users(id);


--
-- TOC entry 4065 (class 2606 OID 19997)
-- Name: user_account_associations user_account_associations_user_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.user_account_associations
    ADD CONSTRAINT user_account_associations_user_id_fkey FOREIGN KEY (user_id) REFERENCES migration.users(id) ON DELETE CASCADE;


--
-- TOC entry 4052 (class 2606 OID 19876)
-- Name: user_profiles user_profiles_approved_by_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.user_profiles
    ADD CONSTRAINT user_profiles_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES migration.users(id);


--
-- TOC entry 4053 (class 2606 OID 19881)
-- Name: user_profiles user_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.user_profiles
    ADD CONSTRAINT user_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES migration.users(id) ON DELETE CASCADE;


--
-- TOC entry 4104 (class 2606 OID 20406)
-- Name: user_roles user_roles_assigned_by_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.user_roles
    ADD CONSTRAINT user_roles_assigned_by_fkey FOREIGN KEY (assigned_by) REFERENCES migration.users(id);


--
-- TOC entry 4105 (class 2606 OID 20411)
-- Name: user_roles user_roles_scope_client_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.user_roles
    ADD CONSTRAINT user_roles_scope_client_id_fkey FOREIGN KEY (scope_client_id) REFERENCES migration.client_accounts(id);


--
-- TOC entry 4106 (class 2606 OID 20416)
-- Name: user_roles user_roles_scope_engagement_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.user_roles
    ADD CONSTRAINT user_roles_scope_engagement_id_fkey FOREIGN KEY (scope_engagement_id) REFERENCES migration.engagements(id);


--
-- TOC entry 4107 (class 2606 OID 20421)
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES migration.users(id) ON DELETE CASCADE;


--
-- TOC entry 4108 (class 2606 OID 20447)
-- Name: wave_plans wave_plans_client_account_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.wave_plans
    ADD CONSTRAINT wave_plans_client_account_id_fkey FOREIGN KEY (client_account_id) REFERENCES migration.client_accounts(id) ON DELETE CASCADE;


--
-- TOC entry 4109 (class 2606 OID 20452)
-- Name: wave_plans wave_plans_engagement_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.wave_plans
    ADD CONSTRAINT wave_plans_engagement_id_fkey FOREIGN KEY (engagement_id) REFERENCES migration.engagements(id) ON DELETE CASCADE;


--
-- TOC entry 4110 (class 2606 OID 20457)
-- Name: wave_plans wave_plans_migration_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.wave_plans
    ADD CONSTRAINT wave_plans_migration_id_fkey FOREIGN KEY (migration_id) REFERENCES migration.migrations(id);


--
-- TOC entry 4152 (class 2606 OID 20887)
-- Name: workflow_progress workflow_progress_asset_id_fkey; Type: FK CONSTRAINT; Schema: migration; Owner: postgres
--

ALTER TABLE ONLY migration.workflow_progress
    ADD CONSTRAINT workflow_progress_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES migration.assets(id) ON DELETE CASCADE;


-- Completed on 2025-06-22 22:31:53 UTC

--
-- PostgreSQL database dump complete
--

