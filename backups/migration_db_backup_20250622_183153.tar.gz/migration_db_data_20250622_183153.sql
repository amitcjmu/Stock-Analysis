--
-- PostgreSQL database dump
--

-- Dumped from database version 16.8 (Debian 16.8-1.pgdg120+1)
-- Dumped by pg_dump version 16.8 (Debian 16.8-1.pgdg120+1)

-- Started on 2025-06-22 22:31:53 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 4240 (class 0 OID 19785)
-- Dependencies: 226
-- Data for Name: users; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.users (id, email, password_hash, first_name, last_name, is_active, is_verified, is_mock, created_at, updated_at, last_login) FROM stdin;
347d1ecd-04f6-4e3a-86ca-d35703512301	chocka@gmail.com	$2b$12$EHD0rkgH1L63OTGjTmcJ7uxp.ElzestGXzzmlQC6ZGPEONy4ptoNq	Chocka	User	t	t	f	2025-06-22 22:17:09.619813+00	2025-06-22 22:17:09.619816+00	\N
12954bcb-b694-4f67-a804-22faa909e51e	demo@aiforce.com	$2b$12$KUiMIeofmGGh8MywaF.2T.7MRcqs0HewGOEtm5ujxGtIxko6u2iXa	Demo	User	t	t	f	2025-06-22 22:17:09.934795+00	2025-06-22 22:17:09.934797+00	\N
55555555-5555-5555-5555-555555555555	admin@democorp.com	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhZ8/iGda9iaHeqM1a3huS	Admin	User	t	f	f	2025-06-22 22:26:35.828428+00	\N	\N
44444444-4444-4444-4444-444444444444	demo@democorp.com	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhZ8/iGda9iaHeqM1a3huS	Demo	User	t	f	t	2025-06-22 22:26:35.914019+00	\N	\N
\.


--
-- TOC entry 4242 (class 0 OID 19815)
-- Dependencies: 228
-- Data for Name: client_accounts; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.client_accounts (id, name, slug, description, industry, company_size, headquarters_location, primary_contact_name, primary_contact_email, primary_contact_phone, subscription_tier, billing_contact_email, settings, branding, business_objectives, it_guidelines, decision_criteria, agent_preferences, is_mock, created_at, updated_at, created_by, is_active) FROM stdin;
11111111-1111-1111-1111-111111111111	Democorp	democorp	Demo corporation for testing platform features	Technology	Enterprise	Demo City, Demo State	\N	\N	\N	standard	\N	{}	{}	{"primary_goals": [], "timeframe": "", "success_metrics": [], "budget_constraints": "", "compliance_requirements": []}	{"architecture_patterns": [], "security_requirements": [], "compliance_standards": [], "technology_preferences": [], "cloud_strategy": "", "data_governance": {}}	{"risk_tolerance": "medium", "cost_sensitivity": "medium", "innovation_appetite": "moderate", "timeline_pressure": "medium", "quality_vs_speed": "balanced", "technical_debt_tolerance": "low"}	{"confidence_thresholds": {"field_mapping": 0.8, "data_classification": 0.75, "risk_assessment": 0.85, "migration_strategy": 0.9}, "learning_preferences": ["conservative", "accuracy_focused"], "custom_prompts": {}, "notification_preferences": {"confidence_alerts": true, "learning_updates": false, "error_notifications": true}}	t	2025-06-22 22:26:35.988386+00	\N	\N	t
d838573d-f461-44e4-81b5-5af510ef83b7	Acme Corporation	acme-corp	Leading technology company specializing in cloud solutions	Technology	Enterprise	San Francisco, CA	\N	\N	\N	standard	\N	{}	{}	{"primary_goals": [], "timeframe": "", "success_metrics": [], "budget_constraints": "", "compliance_requirements": []}	{"architecture_patterns": [], "security_requirements": [], "compliance_standards": [], "technology_preferences": [], "cloud_strategy": "", "data_governance": {}}	{"risk_tolerance": "medium", "cost_sensitivity": "medium", "innovation_appetite": "moderate", "timeline_pressure": "medium", "quality_vs_speed": "balanced", "technical_debt_tolerance": "low"}	{"confidence_thresholds": {"field_mapping": 0.8, "data_classification": 0.75, "risk_assessment": 0.85, "migration_strategy": 0.9}, "learning_preferences": ["conservative", "accuracy_focused"], "custom_prompts": {}, "notification_preferences": {"confidence_alerts": true, "learning_updates": false, "error_notifications": true}}	f	2025-06-22 22:26:35.989641+00	\N	\N	t
73dee5f1-6a01-43e3-b1b8-dbe6c66f2990	Marathon Petroleum	marathon-petroleum	Major energy company with extensive infrastructure	Energy	Enterprise	Findlay, OH	\N	\N	\N	standard	\N	{}	{}	{"primary_goals": [], "timeframe": "", "success_metrics": [], "budget_constraints": "", "compliance_requirements": []}	{"architecture_patterns": [], "security_requirements": [], "compliance_standards": [], "technology_preferences": [], "cloud_strategy": "", "data_governance": {}}	{"risk_tolerance": "medium", "cost_sensitivity": "medium", "innovation_appetite": "moderate", "timeline_pressure": "medium", "quality_vs_speed": "balanced", "technical_debt_tolerance": "low"}	{"confidence_thresholds": {"field_mapping": 0.8, "data_classification": 0.75, "risk_assessment": 0.85, "migration_strategy": 0.9}, "learning_preferences": ["conservative", "accuracy_focused"], "custom_prompts": {}, "notification_preferences": {"confidence_alerts": true, "learning_updates": false, "error_notifications": true}}	f	2025-06-22 22:26:35.990564+00	\N	\N	t
\.


--
-- TOC entry 4249 (class 0 OID 19932)
-- Dependencies: 235
-- Data for Name: engagements; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.engagements (id, client_account_id, name, slug, description, engagement_type, status, priority, start_date, target_completion_date, actual_completion_date, engagement_lead_id, client_contact_name, client_contact_email, settings, migration_scope, team_preferences, is_mock, created_at, updated_at, created_by, is_active) FROM stdin;
22222222-2222-2222-2222-222222222222	11111111-1111-1111-1111-111111111111	Cloud Migration 2024	cloud-migration-2024	Demo engagement for cloud migration project	migration	active	medium	2025-06-22 22:26:36.023159+00	\N	\N	\N	\N	\N	{}	{"target_clouds": [], "migration_strategies": [], "excluded_systems": [], "included_environments": [], "business_units": [], "geographic_scope": [], "timeline_constraints": {}}	{"stakeholders": [], "decision_makers": [], "technical_leads": [], "communication_style": "formal", "reporting_frequency": "weekly", "preferred_meeting_times": [], "escalation_contacts": [], "project_methodology": "agile"}	f	2025-06-22 22:26:36.023166+00	\N	55555555-5555-5555-5555-555555555555	t
d1a93e23-719d-4dad-8bbf-b66ab9de2b94	d838573d-f461-44e4-81b5-5af510ef83b7	Cloud Migration Initiative 2024	cloud-migration-initiative-2024	Comprehensive cloud migration project for legacy infrastructure	migration	active	medium	2025-06-22 22:26:36.023951+00	\N	\N	\N	\N	\N	{}	{"target_clouds": [], "migration_strategies": [], "excluded_systems": [], "included_environments": [], "business_units": [], "geographic_scope": [], "timeline_constraints": {}}	{"stakeholders": [], "decision_makers": [], "technical_leads": [], "communication_style": "formal", "reporting_frequency": "weekly", "preferred_meeting_times": [], "escalation_contacts": [], "project_methodology": "agile"}	f	2025-06-22 22:26:36.023954+00	\N	55555555-5555-5555-5555-555555555555	t
90dd2829-c750-4230-bf70-1728ca370283	d838573d-f461-44e4-81b5-5af510ef83b7	Test Fixed Engagement	test-fixed-engagement	Fixed engagement for testing purposes	migration	active	medium	2025-06-22 22:26:36.024471+00	\N	\N	\N	\N	\N	{}	{"target_clouds": [], "migration_strategies": [], "excluded_systems": [], "included_environments": [], "business_units": [], "geographic_scope": [], "timeline_constraints": {}}	{"stakeholders": [], "decision_makers": [], "technical_leads": [], "communication_style": "formal", "reporting_frequency": "weekly", "preferred_meeting_times": [], "escalation_contacts": [], "project_methodology": "agile"}	f	2025-06-22 22:26:36.024473+00	\N	55555555-5555-5555-5555-555555555555	t
baf640df-433c-4bcd-8c8f-7b01c12e9005	73dee5f1-6a01-43e3-b1b8-dbe6c66f2990	Debug Test Engagement	debug-test-engagement	Engagement for debugging and testing	migration	active	medium	2025-06-22 22:26:36.024899+00	\N	\N	\N	\N	\N	{}	{"target_clouds": [], "migration_strategies": [], "excluded_systems": [], "included_environments": [], "business_units": [], "geographic_scope": [], "timeline_constraints": {}}	{"stakeholders": [], "decision_makers": [], "technical_leads": [], "communication_style": "formal", "reporting_frequency": "weekly", "preferred_meeting_times": [], "escalation_contacts": [], "project_methodology": "agile"}	f	2025-06-22 22:26:36.024901+00	\N	55555555-5555-5555-5555-555555555555	t
803fbeb6-caaf-4a17-8526-b1a5baccb9bb	73dee5f1-6a01-43e3-b1b8-dbe6c66f2990	Test Engagement 2	test-engagement-2	Second test engagement for Marathon Petroleum	migration	active	medium	2025-06-22 22:26:36.025267+00	\N	\N	\N	\N	\N	{}	{"target_clouds": [], "migration_strategies": [], "excluded_systems": [], "included_environments": [], "business_units": [], "geographic_scope": [], "timeline_constraints": {}}	{"stakeholders": [], "decision_makers": [], "technical_leads": [], "communication_style": "formal", "reporting_frequency": "weekly", "preferred_meeting_times": [], "escalation_contacts": [], "project_methodology": "agile"}	f	2025-06-22 22:26:36.025269+00	\N	55555555-5555-5555-5555-555555555555	t
\.


--
-- TOC entry 4253 (class 0 OID 20033)
-- Dependencies: 239
-- Data for Name: data_import_sessions; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.data_import_sessions (id, client_account_id, engagement_id, session_name, session_display_name, description, is_default, parent_session_id, session_type, auto_created, source_filename, status, progress_percentage, total_imports, total_assets_processed, total_records_imported, data_quality_score, session_config, business_context, agent_insights, started_at, completed_at, last_activity_at, created_by, is_mock, created_at, updated_at) FROM stdin;
33333333-3333-3333-3333-333333333333	11111111-1111-1111-1111-111111111111	22222222-2222-2222-2222-222222222222	Demo Session	\N	\N	f	\N	data_import	t	\N	active	0	0	0	0	0	{"deduplication_strategy": "engagement_level", "quality_thresholds": {"minimum_completeness": 0.7, "minimum_accuracy": 0.8}, "processing_preferences": {"auto_classify": true, "auto_deduplicate": true, "require_manual_review": false}}	{"import_purpose": "", "data_source_description": "", "expected_changes": [], "validation_notes": []}	{"classification_confidence": 0.0, "data_quality_issues": [], "recommendations": [], "learning_outcomes": []}	2025-06-22 22:26:36.059827+00	\N	2025-06-22 22:26:36.059827+00	55555555-5555-5555-5555-555555555555	f	2025-06-22 22:26:36.065081+00	\N
a1b2c3d4-e5f6-7890-abcd-ef1234567890	d838573d-f461-44e4-81b5-5af510ef83b7	d1a93e23-719d-4dad-8bbf-b66ab9de2b94	Demo Session 1	\N	\N	f	\N	data_import	t	\N	active	0	0	0	0	0	{"deduplication_strategy": "engagement_level", "quality_thresholds": {"minimum_completeness": 0.7, "minimum_accuracy": 0.8}, "processing_preferences": {"auto_classify": true, "auto_deduplicate": true, "require_manual_review": false}}	{"import_purpose": "", "data_source_description": "", "expected_changes": [], "validation_notes": []}	{"classification_confidence": 0.0, "data_quality_issues": [], "recommendations": [], "learning_outcomes": []}	2025-06-22 22:26:36.059827+00	\N	2025-06-22 22:26:36.059827+00	55555555-5555-5555-5555-555555555555	f	2025-06-22 22:26:36.065893+00	\N
b2c3d4e5-f6a7-8901-bcde-f23456789012	d838573d-f461-44e4-81b5-5af510ef83b7	90dd2829-c750-4230-bf70-1728ca370283	Test Session	\N	\N	f	\N	data_import	t	\N	active	0	0	0	0	0	{"deduplication_strategy": "engagement_level", "quality_thresholds": {"minimum_completeness": 0.7, "minimum_accuracy": 0.8}, "processing_preferences": {"auto_classify": true, "auto_deduplicate": true, "require_manual_review": false}}	{"import_purpose": "", "data_source_description": "", "expected_changes": [], "validation_notes": []}	{"classification_confidence": 0.0, "data_quality_issues": [], "recommendations": [], "learning_outcomes": []}	2025-06-22 22:26:36.059827+00	\N	2025-06-22 22:26:36.059827+00	55555555-5555-5555-5555-555555555555	f	2025-06-22 22:26:36.066485+00	\N
\.


--
-- TOC entry 4267 (class 0 OID 20465)
-- Dependencies: 253
-- Data for Name: access_audit_log; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.access_audit_log (id, user_id, action_type, resource_type, resource_id, client_account_id, engagement_id, session_id, result, reason, ip_address, user_agent, details, created_at) FROM stdin;
\.


--
-- TOC entry 4233 (class 0 OID 19228)
-- Dependencies: 219
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.alembic_version (version_num) FROM stdin;
39181c8d85b8
\.


--
-- TOC entry 4236 (class 0 OID 19735)
-- Dependencies: 222
-- Data for Name: migrations; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.migrations (id, name, description, status, current_phase, created_at, updated_at, start_date, target_completion_date, actual_completion_date, source_environment, target_environment, migration_strategy, progress_percentage, total_assets, migrated_assets, ai_recommendations, risk_assessment, cost_estimates, settings) FROM stdin;
\.


--
-- TOC entry 4268 (class 0 OID 20535)
-- Dependencies: 254
-- Data for Name: assets; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.assets (id, client_account_id, engagement_id, session_id, migration_id, name, asset_name, hostname, asset_type, description, ip_address, fqdn, mac_address, environment, location, datacenter, rack_location, availability_zone, operating_system, os_version, cpu_cores, memory_gb, storage_gb, business_owner, technical_owner, department, application_name, technology_stack, criticality, business_criticality, custom_attributes, six_r_strategy, mapping_status, migration_priority, migration_complexity, migration_wave, sixr_ready, status, migration_status, dependencies, related_assets, discovery_method, discovery_source, discovery_timestamp, cpu_utilization_percent, memory_utilization_percent, disk_iops, network_throughput_mbps, completeness_score, quality_score, current_monthly_cost, estimated_cloud_cost, imported_by, imported_at, source_filename, raw_data, field_mappings_used, is_mock, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- TOC entry 4274 (class 0 OID 20709)
-- Dependencies: 260
-- Data for Name: assessments; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.assessments (id, client_account_id, engagement_id, migration_id, asset_id, assessment_type, status, title, description, overall_score, risk_level, confidence_level, recommended_strategy, alternative_strategies, strategy_rationale, current_cost, estimated_migration_cost, estimated_target_cost, cost_savings_potential, roi_months, identified_risks, risk_mitigation, blockers, dependencies_impact, technical_complexity, compatibility_score, modernization_opportunities, performance_impact, business_criticality, downtime_requirements, user_impact, compliance_considerations, ai_insights, ai_confidence, ai_model_version, estimated_effort_hours, estimated_duration_days, recommended_wave, prerequisites, assessor, assessment_date, review_date, approval_date, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4275 (class 0 OID 20741)
-- Dependencies: 261
-- Data for Name: asset_dependencies; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.asset_dependencies (id, asset_id, depends_on_asset_id, dependency_type, description, is_mock, created_at) FROM stdin;
\.


--
-- TOC entry 4276 (class 0 OID 20759)
-- Dependencies: 262
-- Data for Name: asset_embeddings; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.asset_embeddings (id, asset_id, client_account_id, engagement_id, embedding, source_text, embedding_model, is_mock, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4250 (class 0 OID 19960)
-- Dependencies: 236
-- Data for Name: tags; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.tags (id, client_account_id, name, category, description, reference_embedding, confidence_threshold, is_active, is_mock, usage_count, last_used, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4277 (class 0 OID 20787)
-- Dependencies: 263
-- Data for Name: asset_tags; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.asset_tags (id, asset_id, tag_id, confidence_score, assigned_method, assigned_by, is_validated, validated_by, validated_at, is_mock, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4246 (class 0 OID 19867)
-- Dependencies: 232
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.user_profiles (user_id, status, approval_requested_at, approved_at, approved_by, registration_reason, organization, role_description, requested_access_level, phone_number, manager_email, linkedin_profile, last_login_at, login_count, failed_login_attempts, last_failed_login, notification_preferences, created_at, updated_at) FROM stdin;
347d1ecd-04f6-4e3a-86ca-d35703512301	active	2025-06-22 22:17:09.97021+00	\N	\N	\N	AI Force	Platform Administrator	read_only	\N	\N	\N	\N	0	0	\N	{"email_notifications": true, "system_alerts": true, "learning_updates": false, "weekly_reports": true}	2025-06-22 22:17:09.699873+00	2025-06-22 22:17:09.699876+00
12954bcb-b694-4f67-a804-22faa909e51e	active	2025-06-22 22:17:09.97021+00	\N	\N	\N	Demo Organization	Demo User	read_only	\N	\N	\N	\N	0	0	\N	{"email_notifications": true, "system_alerts": true, "learning_updates": false, "weekly_reports": true}	2025-06-22 22:17:09.934897+00	2025-06-22 22:17:09.934897+00
55555555-5555-5555-5555-555555555555	active	2025-06-22 22:26:36.103303+00	2025-06-22 22:26:36.104774+00	55555555-5555-5555-5555-555555555555	Platform administrator	AI Force	Platform Administrator	super_admin	\N	\N	\N	\N	0	0	\N	{"email_notifications": true, "system_alerts": true, "learning_updates": false, "weekly_reports": true}	2025-06-22 22:26:36.104777+00	\N
44444444-4444-4444-4444-444444444444	active	2025-06-22 22:26:36.103303+00	2025-06-22 22:26:36.105692+00	55555555-5555-5555-5555-555555555555	Demo user for testing	Acme Corporation	Client Administrator	admin	\N	\N	\N	\N	0	0	\N	{"email_notifications": true, "system_alerts": true, "learning_updates": false, "weekly_reports": true}	2025-06-22 22:26:36.105717+00	\N
\.


--
-- TOC entry 4247 (class 0 OID 19887)
-- Dependencies: 233
-- Data for Name: client_access; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.client_access (id, user_profile_id, client_account_id, access_level, permissions, restricted_environments, restricted_data_types, granted_at, granted_by, expires_at, is_active, last_accessed_at, access_count, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4252 (class 0 OID 20005)
-- Dependencies: 238
-- Data for Name: cmdb_sixr_analyses; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.cmdb_sixr_analyses (id, client_account_id, engagement_id, analysis_name, description, status, total_assets, rehost_count, replatform_count, refactor_count, rearchitect_count, retire_count, retain_count, total_current_cost, total_estimated_cost, potential_savings, analysis_results, recommendations, is_mock, created_at, updated_at, created_by) FROM stdin;
\.


--
-- TOC entry 4241 (class 0 OID 19797)
-- Dependencies: 227
-- Data for Name: workflow_states; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.workflow_states (id, flow_id, session_id, client_account_id, engagement_id, user_id, workflow_type, current_phase, status, progress_percentage, phase_completion, crew_status, state_data, field_mappings, cleaned_data, asset_inventory, dependencies, technical_debt, data_quality_metrics, agent_insights, success_criteria, errors, warnings, workflow_log, discovery_summary, assessment_flow_package, database_assets_created, database_integration_status, learning_scope, memory_isolation_level, shared_memory_id, expiration_date, auto_cleanup_eligible, deletion_scheduled_at, last_user_activity, flow_resumption_data, agent_memory_refs, knowledge_base_refs, created_at, updated_at, started_at, completed_at) FROM stdin;
\.


--
-- TOC entry 4243 (class 0 OID 19832)
-- Dependencies: 229
-- Data for Name: crewai_flow_state_extensions; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.crewai_flow_state_extensions (id, workflow_state_id, session_id, flow_id, flow_persistence_data, agent_collaboration_log, memory_usage_metrics, knowledge_base_analytics, phase_execution_times, agent_performance_metrics, crew_coordination_analytics, learning_patterns, user_feedback_history, adaptation_metrics, resumption_checkpoints, state_snapshots, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4248 (class 0 OID 19915)
-- Dependencies: 234
-- Data for Name: custom_target_fields; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.custom_target_fields (id, client_account_id, field_name, field_type, description, is_required, is_critical, created_at, updated_at, created_by, validation_schema, default_value, allowed_values) FROM stdin;
\.


--
-- TOC entry 4269 (class 0 OID 20590)
-- Dependencies: 255
-- Data for Name: data_imports; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.data_imports (id, client_account_id, engagement_id, session_id, import_name, import_type, description, source_filename, file_size_bytes, file_type, file_hash, status, progress_percentage, total_records, processed_records, failed_records, import_config, imported_by, started_at, completed_at, is_mock, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4280 (class 0 OID 20847)
-- Dependencies: 266
-- Data for Name: raw_import_records; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.raw_import_records (id, data_import_id, client_account_id, engagement_id, session_id, row_number, record_id, raw_data, processed_data, validation_errors, processing_notes, is_processed, is_valid, asset_id, created_at, processed_at) FROM stdin;
\.


--
-- TOC entry 4282 (class 0 OID 20892)
-- Dependencies: 268
-- Data for Name: data_quality_issues; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.data_quality_issues (id, data_import_id, raw_record_id, issue_type, field_name, current_value, suggested_value, severity, confidence_score, reasoning, status, resolution_method, resolved_by, resolution_notes, detected_at, resolved_at) FROM stdin;
\.


--
-- TOC entry 4254 (class 0 OID 20070)
-- Dependencies: 240
-- Data for Name: engagement_access; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.engagement_access (id, user_profile_id, engagement_id, access_level, engagement_role, permissions, restricted_sessions, allowed_session_types, granted_at, granted_by, expires_at, is_active, last_accessed_at, access_count, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4255 (class 0 OID 20098)
-- Dependencies: 241
-- Data for Name: enhanced_access_audit_log; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.enhanced_access_audit_log (id, user_id, action_type, resource_type, resource_id, client_account_id, engagement_id, result, reason, ip_address, user_agent, details, user_role_level, user_data_scope, created_at) FROM stdin;
\.


--
-- TOC entry 4256 (class 0 OID 20124)
-- Dependencies: 242
-- Data for Name: enhanced_user_profiles; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.enhanced_user_profiles (user_id, status, role_level, data_scope, scope_client_account_id, scope_engagement_id, registration_reason, organization, role_description, phone_number, manager_email, approval_requested_at, approved_at, approved_by, last_login_at, login_count, failed_login_attempts, is_deleted, deleted_at, deleted_by, delete_reason, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4257 (class 0 OID 20162)
-- Dependencies: 243
-- Data for Name: feedback; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.feedback (id, feedback_type, page, rating, comment, category, breadcrumb, filename, original_analysis, user_corrections, asset_type_override, status, processed, user_agent, user_timestamp, client_ip, client_account_id, engagement_id, learning_patterns_extracted, confidence_impact, created_at, updated_at, processed_at) FROM stdin;
\.


--
-- TOC entry 4258 (class 0 OID 20183)
-- Dependencies: 244
-- Data for Name: feedback_summaries; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.feedback_summaries (id, feedback_type, page, time_period, total_feedback, average_rating, status_counts, rating_distribution, category_counts, feedback_trend, rating_trend, client_account_id, engagement_id, last_calculated, calculation_duration_ms) FROM stdin;
\.


--
-- TOC entry 4234 (class 0 OID 19678)
-- Dependencies: 220
-- Data for Name: flow_deletion_audit; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.flow_deletion_audit (id, session_id, flow_id, client_account_id, engagement_id, user_id, deletion_type, deletion_reason, deletion_method, data_deleted, deletion_impact, cleanup_summary, shared_memory_cleaned, knowledge_base_refs_cleaned, agent_memory_cleaned, deleted_at, deleted_by, deletion_duration_ms, recovery_possible, recovery_data) FROM stdin;
\.


--
-- TOC entry 4278 (class 0 OID 20816)
-- Dependencies: 264
-- Data for Name: import_field_mappings; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.import_field_mappings (id, data_import_id, source_field, target_field, mapping_type, confidence_score, is_user_defined, is_validated, validation_method, status, user_feedback, original_ai_suggestion, correction_reason, transformation_logic, validation_rules, sample_values, suggested_by, validated_by, created_at, validated_at) FROM stdin;
\.


--
-- TOC entry 4279 (class 0 OID 20834)
-- Dependencies: 265
-- Data for Name: import_processing_steps; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.import_processing_steps (id, data_import_id, step_name, step_order, status, description, input_data, output_data, error_details, records_processed, duration_seconds, started_at, completed_at) FROM stdin;
\.


--
-- TOC entry 4235 (class 0 OID 19692)
-- Dependencies: 221
-- Data for Name: llm_model_pricing; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.llm_model_pricing (id, created_at, updated_at, provider, model_name, model_version, input_cost_per_1k_tokens, output_cost_per_1k_tokens, currency, effective_from, effective_to, is_active, source, notes) FROM stdin;
\.


--
-- TOC entry 4259 (class 0 OID 20204)
-- Dependencies: 245
-- Data for Name: llm_usage_logs; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.llm_usage_logs (id, created_at, updated_at, client_account_id, engagement_id, user_id, username, session_id, request_id, endpoint, page_context, feature_context, llm_provider, model_name, model_version, input_tokens, output_tokens, total_tokens, input_cost, output_cost, total_cost, cost_currency, response_time_ms, success, error_type, error_message, request_data, response_data, additional_metadata, ip_address, user_agent) FROM stdin;
\.


--
-- TOC entry 4260 (class 0 OID 20233)
-- Dependencies: 246
-- Data for Name: llm_usage_summary; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.llm_usage_summary (id, created_at, updated_at, period_type, period_start, period_end, client_account_id, engagement_id, user_id, llm_provider, model_name, page_context, feature_context, total_requests, successful_requests, failed_requests, total_input_tokens, total_output_tokens, total_tokens, total_cost, avg_response_time_ms, min_response_time_ms, max_response_time_ms) FROM stdin;
\.


--
-- TOC entry 4261 (class 0 OID 20257)
-- Dependencies: 247
-- Data for Name: mapping_learning_patterns; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.mapping_learning_patterns (id, source_column, target_column, pattern_type, pattern_details, confidence_score, created_by, last_used_at, usage_count, engagement_id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4245 (class 0 OID 19852)
-- Dependencies: 231
-- Data for Name: migration_logs; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.migration_logs (id, migration_id, "timestamp", level, message, details, phase, user_id, action) FROM stdin;
\.


--
-- TOC entry 4262 (class 0 OID 20275)
-- Dependencies: 248
-- Data for Name: migration_waves; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.migration_waves (id, client_account_id, engagement_id, wave_number, name, description, status, planned_start_date, planned_end_date, actual_start_date, actual_end_date, total_assets, completed_assets, failed_assets, estimated_cost, actual_cost, estimated_effort_hours, actual_effort_hours, is_mock, created_at, updated_at, created_by) FROM stdin;
\.


--
-- TOC entry 4237 (class 0 OID 19745)
-- Dependencies: 223
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.role_permissions (id, role_level, can_manage_platform_settings, can_manage_all_clients, can_manage_all_users, can_purge_deleted_data, can_view_system_logs, can_create_clients, can_modify_client_settings, can_manage_client_users, can_delete_client_data, can_create_engagements, can_modify_engagement_settings, can_manage_engagement_users, can_delete_engagement_data, can_import_data, can_export_data, can_view_analytics, can_modify_data, can_configure_agents, can_view_agent_insights, can_approve_agent_decisions, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4263 (class 0 OID 20333)
-- Dependencies: 249
-- Data for Name: sixr_analyses; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.sixr_analyses (id, migration_id, client_account_id, engagement_id, name, description, status, priority, application_ids, application_data, current_iteration, progress_percentage, estimated_completion, final_recommendation, confidence_score, created_by, updated_by, created_at, updated_at, analysis_config) FROM stdin;
\.


--
-- TOC entry 4270 (class 0 OID 20619)
-- Dependencies: 256
-- Data for Name: sixr_analysis_parameters; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.sixr_analysis_parameters (id, analysis_id, iteration_number, business_value, technical_complexity, migration_urgency, compliance_requirements, cost_sensitivity, risk_tolerance, innovation_priority, application_type, parameter_source, confidence_level, created_by, updated_by, created_at, updated_at, parameter_notes, validation_status) FROM stdin;
\.


--
-- TOC entry 4271 (class 0 OID 20633)
-- Dependencies: 257
-- Data for Name: sixr_iterations; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.sixr_iterations (id, analysis_id, iteration_number, iteration_name, iteration_reason, stakeholder_feedback, parameter_changes, question_responses, recommendation_data, confidence_score, analysis_duration, agent_insights, status, error_details, created_by, created_at, completed_at) FROM stdin;
\.


--
-- TOC entry 4238 (class 0 OID 19752)
-- Dependencies: 224
-- Data for Name: sixr_parameters; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.sixr_parameters (id, parameter_key, value, description, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4239 (class 0 OID 19775)
-- Dependencies: 225
-- Data for Name: sixr_questions; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.sixr_questions (id, question_id, question_text, question_type, category, priority, required, active, options, validation_rules, help_text, depends_on, show_conditions, skip_conditions, created_by, updated_by, created_at, updated_at, version, parent_question_id) FROM stdin;
\.


--
-- TOC entry 4272 (class 0 OID 20647)
-- Dependencies: 258
-- Data for Name: sixr_question_responses; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.sixr_question_responses (id, analysis_id, iteration_number, question_id, response_value, response_text, confidence, source, response_time, validation_status, validation_errors, created_by, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4273 (class 0 OID 20666)
-- Dependencies: 259
-- Data for Name: sixr_recommendations; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.sixr_recommendations (id, analysis_id, iteration_number, recommended_strategy, confidence_score, strategy_scores, key_factors, assumptions, next_steps, estimated_effort, estimated_timeline, estimated_cost_impact, risk_factors, business_benefits, technical_benefits, created_at, updated_at, created_by) FROM stdin;
\.


--
-- TOC entry 4264 (class 0 OID 20360)
-- Dependencies: 250
-- Data for Name: soft_deleted_items; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.soft_deleted_items (id, item_type, item_id, item_name, client_account_id, engagement_id, deleted_by, deleted_at, delete_reason, reviewed_by, reviewed_at, review_decision, review_notes, purged_at, purged_by, status, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4283 (class 0 OID 20916)
-- Dependencies: 269
-- Data for Name: test_table; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.test_table (id) FROM stdin;
\.


--
-- TOC entry 4251 (class 0 OID 19979)
-- Dependencies: 237
-- Data for Name: user_account_associations; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.user_account_associations (id, user_id, client_account_id, role, is_mock, created_at, updated_at, created_by) FROM stdin;
\.


--
-- TOC entry 4265 (class 0 OID 20397)
-- Dependencies: 251
-- Data for Name: user_roles; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.user_roles (id, user_id, role_type, role_name, description, permissions, scope_type, scope_client_id, scope_engagement_id, is_active, assigned_at, assigned_by, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4266 (class 0 OID 20439)
-- Dependencies: 252
-- Data for Name: wave_plans; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.wave_plans (id, client_account_id, engagement_id, migration_id, wave_number, wave_name, description, planned_start_date, planned_end_date, actual_start_date, actual_end_date, total_assets, completed_assets, estimated_effort_hours, estimated_cost, prerequisites, dependencies, constraints, overall_risk_level, complexity_score, success_criteria, status, progress_percentage, ai_recommendations, optimization_score, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4281 (class 0 OID 20880)
-- Dependencies: 267
-- Data for Name: workflow_progress; Type: TABLE DATA; Schema: migration; Owner: postgres
--

COPY migration.workflow_progress (id, asset_id, stage, status, notes, is_mock, started_at, completed_at) FROM stdin;
\.


--
-- TOC entry 4289 (class 0 OID 0)
-- Dependencies: 230
-- Name: migration_logs_id_seq; Type: SEQUENCE SET; Schema: migration; Owner: postgres
--

SELECT pg_catalog.setval('migration.migration_logs_id_seq', 1, false);


-- Completed on 2025-06-22 22:31:53 UTC

--
-- PostgreSQL database dump complete
--

